import { Link } from "react-router-dom";
import { Bell, Search, User, Leaf } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Navbar() {
  return (
    <nav className="sticky top-0 z-50 w-full border-b border-border/60 bg-background/80 backdrop-blur-md">
      <div className="container flex h-16 items-center justify-between">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-primary flex items-center justify-center shadow-glow-primary">
            <Leaf className="w-4.5 h-4.5 text-primary-foreground" />
          </div>
          <span className="font-display font-bold text-lg text-foreground">
            Climate<span className="text-primary">Sense</span> AI
          </span>
        </Link>

        {/* Nav links */}
        <div className="hidden md:flex items-center gap-6">
          <Link to="/#features" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">Features</Link>
          <Link to="/#impact" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">Impact</Link>
          <Link to="/#events" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">Events</Link>
          <Link to="/dashboard" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">Dashboard</Link>
        </div>

        {/* CTA */}
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="sm" className="hidden md:flex text-muted-foreground hover:text-foreground">
            Sign In
          </Button>
          <Button asChild size="sm" className="bg-primary text-primary-foreground hover:bg-primary/90 shadow-glow-primary font-semibold">
            <Link to="/dashboard">Get Started Free</Link>
          </Button>
        </div>
      </div>
    </nav>
  );
}
