import { motion, useInView } from "framer-motion";
import { useRef, useState, useEffect } from "react";
import { Link } from "react-router-dom";
import {
  Calculator, Bell, Bot, BarChart3, Users, Calendar,
  ArrowRight, Leaf, Globe, Zap, TrendingDown, Shield,
  ChevronRight, Star, Play, Twitter, Github, Linkedin,
  TreePine, Wind, Droplets, Sun, Award
} from "lucide-react";
import { Button } from "@/components/ui/button";
import Navbar from "@/components/Navbar";
import heroViz from "@/assets/hero-viz.png";

// ─── Animated counter ────────────────────────────────────────────────────────
function AnimatedCounter({ target, suffix = "", prefix = "" }: { target: number; suffix?: string; prefix?: string }) {
  const [count, setCount] = useState(0);
  const ref = useRef(null);
  const inView = useInView(ref, { once: true });

  useEffect(() => {
    if (!inView) return;
    const duration = 2000;
    const step = target / (duration / 16);
    let current = 0;
    const timer = setInterval(() => {
      current = Math.min(current + step, target);
      setCount(Math.floor(current));
      if (current >= target) clearInterval(timer);
    }, 16);
    return () => clearInterval(timer);
  }, [inView, target]);

  return (
    <span ref={ref}>
      {prefix}{count.toLocaleString()}{suffix}
    </span>
  );
}

// ─── Feature data ─────────────────────────────────────────────────────────────
const features = [
  {
    icon: Calculator,
    title: "Carbon Footprint Tracker",
    description: "Calculate emissions from transportation, energy, food & lifestyle with detailed insights and reduction tips.",
    color: "text-primary",
    bg: "bg-primary/10",
    path: "/calculator",
  },
  {
    icon: Bell,
    title: "Climate Risk Alerts",
    description: "Location-based heatwave, air pollution, extreme weather, and flood alerts with safety recommendations.",
    color: "text-destructive",
    bg: "bg-destructive/10",
    path: "/alerts",
  },
  {
    icon: Bot,
    title: "AI Sustainability Advisor",
    description: "Chat with an AI advisor to get personalized eco-friendly habits, energy tips, and climate education.",
    color: "text-secondary",
    bg: "bg-secondary/10",
    path: "/advisor",
  },
  {
    icon: BarChart3,
    title: "Environmental Analytics",
    description: "Interactive dashboards showing emission trends, sustainability progress, and personal impact scores.",
    color: "text-primary",
    bg: "bg-primary/10",
    path: "/dashboard",
  },
  {
    icon: Users,
    title: "Volunteer Network",
    description: "Join a global network of climate volunteers. Track hours, earn badges, and make a visible impact.",
    color: "text-secondary",
    bg: "bg-secondary/10",
    path: "/volunteer",
  },
  {
    icon: Calendar,
    title: "Climate Action Events",
    description: "Discover tree plantation drives, beach cleanups, sustainability workshops, and local campaigns.",
    color: "text-warning",
    bg: "bg-warning/10",
    path: "/events",
  },
];

const stats = [
  { value: 24800, suffix: "+", label: "Tonnes CO₂ Reduced", icon: TrendingDown, color: "text-primary" },
  { value: 12400, suffix: "+", label: "Volunteers Joined", icon: Users, color: "text-secondary" },
  { value: 89000, suffix: "+", label: "Trees Planted", icon: TreePine, color: "text-primary" },
  { value: 340, suffix: " tonnes", label: "Waste Collected", icon: Droplets, color: "text-secondary" },
];

const events = [
  {
    title: "City Tree Plantation Drive",
    date: "Mar 22, 2025",
    location: "Central Park, NY",
    category: "Plantation",
    volunteers: 45,
    color: "border-l-primary",
  },
  {
    title: "Marina Beach Cleanup",
    date: "Mar 28, 2025",
    location: "Marina Beach, CA",
    category: "Cleanup",
    volunteers: 78,
    color: "border-l-secondary",
  },
  {
    title: "Renewable Energy Workshop",
    date: "Apr 5, 2025",
    location: "Tech Hub, Austin",
    category: "Workshop",
    volunteers: 32,
    color: "border-l-warning",
  },
  {
    title: "Zero Waste Community Day",
    date: "Apr 12, 2025",
    location: "City Center, Chicago",
    category: "Awareness",
    volunteers: 91,
    color: "border-l-primary",
  },
];

const testimonials = [
  {
    name: "Sarah Chen",
    role: "Environmental Activist",
    avatar: "SC",
    text: "ClimateSense AI helped me reduce my carbon footprint by 40% in just 3 months. The AI advisor is incredibly helpful!",
    stars: 5,
  },
  {
    name: "Marcus Rodriguez",
    role: "Sustainability Manager",
    avatar: "MR",
    text: "The climate alerts saved our team from outdoor events during dangerous heatwaves. A must-have for every organization.",
    stars: 5,
  },
  {
    name: "Priya Patel",
    role: "Climate Researcher",
    avatar: "PP",
    text: "The analytics dashboard gives me exactly the data I need to track community impact. Beautiful and functional.",
    stars: 5,
  },
];

// ─── Main component ───────────────────────────────────────────────────────────
export default function Index() {
  const fadeUp = {
    hidden: { opacity: 0, y: 32 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: [0.25, 0.1, 0.25, 1] as const } },
  };

  const stagger = {
    hidden: {},
    visible: { transition: { staggerChildren: 0.1 } },
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* ── Hero ──────────────────────────────────────────────────────────── */}
      <section className="relative overflow-hidden pt-16 pb-24 md:pt-24 md:pb-32">
        {/* Background gradient */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-0 left-0 right-0 h-[600px] bg-gradient-to-br from-primary/8 via-background to-secondary/6" />
          <div className="absolute top-20 left-1/4 w-96 h-96 rounded-full bg-primary/5 blur-3xl" />
          <div className="absolute top-40 right-1/4 w-80 h-80 rounded-full bg-secondary/5 blur-3xl" />
        </div>

        <div className="container relative grid lg:grid-cols-2 gap-12 items-center">
          {/* Left – copy */}
          <motion.div
            variants={stagger}
            initial="hidden"
            animate="visible"
            className="flex flex-col gap-6"
          >
            <motion.div variants={fadeUp}>
              <span className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 text-primary text-xs font-semibold border border-primary/20">
                <span className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse-slow" />
                Supporting UN SDG 13 – Climate Action
              </span>
            </motion.div>

            <motion.h1 variants={fadeUp} className="font-display text-4xl md:text-5xl lg:text-6xl font-extrabold leading-tight text-foreground">
              Smart Climate{" "}
              <span className="gradient-text">Risk Alerts</span>{" "}
              &amp; Carbon Tracker
            </motion.h1>

            <motion.p variants={fadeUp} className="text-lg text-muted-foreground leading-relaxed max-w-xl">
              Track your carbon footprint, receive real-time climate alerts powered by AI, and join a global community taking action for a sustainable future.
            </motion.p>

            <motion.div variants={fadeUp} className="flex flex-wrap gap-4">
              <Button asChild size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90 shadow-glow-primary font-semibold h-12 px-8">
                <Link to="/calculator">
                  <Calculator className="w-4 h-4 mr-2" />
                  Start Tracking
                </Link>
              </Button>
              <Button asChild variant="outline" size="lg" className="h-12 px-8 font-semibold border-primary/30 text-primary hover:bg-primary/5">
                <Link to="/events">
                  <Globe className="w-4 h-4 mr-2" />
                  Explore Climate Action
                </Link>
              </Button>
            </motion.div>

            <motion.div variants={fadeUp} className="flex items-center gap-6 pt-2">
              <div className="flex -space-x-2">
                {["A", "B", "C", "D"].map((l, i) => (
                  <div key={i} className="w-8 h-8 rounded-full bg-gradient-to-br from-primary/40 to-secondary/40 border-2 border-background flex items-center justify-center text-xs font-bold text-foreground">
                    {l}
                  </div>
                ))}
              </div>
              <div className="text-sm text-muted-foreground">
                <span className="font-semibold text-foreground">12,400+</span> volunteers already joined
              </div>
            </motion.div>
          </motion.div>

          {/* Right – visualization */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative"
          >
            <div className="relative rounded-2xl overflow-hidden border border-border/40 shadow-elevated bg-card">
              <img src={heroViz} alt="Climate data visualization" className="w-full object-cover" />
              {/* Overlay cards */}
              <motion.div
                animate={{ y: [0, -6, 0] }}
                transition={{ repeat: Infinity, duration: 3, ease: "easeInOut" }}
                className="absolute top-4 left-4 glass-card px-4 py-3 rounded-xl shadow-elevated"
              >
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-destructive animate-ping" />
                  <span className="text-xs font-semibold text-foreground">Heatwave Alert — Level 3</span>
                </div>
                <p className="text-xs text-muted-foreground mt-0.5">Mumbai, India · Right now</p>
              </motion.div>
              <motion.div
                animate={{ y: [0, 6, 0] }}
                transition={{ repeat: Infinity, duration: 4, ease: "easeInOut", delay: 1 }}
                className="absolute bottom-4 right-4 glass-card px-4 py-3 rounded-xl shadow-elevated"
              >
                <div className="flex items-center gap-2">
                  <TrendingDown className="w-4 h-4 text-primary" />
                  <span className="text-xs font-bold text-primary">−18% CO₂</span>
                </div>
                <p className="text-xs text-muted-foreground">vs. last month</p>
              </motion.div>
            </div>

            {/* Floating badge */}
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.8, type: "spring" }}
              className="absolute -bottom-5 -left-5 glass-card rounded-2xl px-4 py-3 shadow-elevated"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
                  <Award className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <p className="text-sm font-bold text-foreground">Eco Warrior</p>
                  <p className="text-xs text-muted-foreground">Sustainability Score: 87</p>
                </div>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* ── Stats strip ────────────────────────────────────────────────────── */}
      <section id="impact" className="py-16 border-y border-border/60 bg-card/30">
        <div className="container">
          <motion.div
            variants={stagger}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid grid-cols-2 md:grid-cols-4 gap-8"
          >
            {stats.map((stat, i) => (
              <motion.div key={i} variants={fadeUp} className="flex flex-col items-center text-center gap-2">
                <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center mb-1">
                  <stat.icon className={`w-6 h-6 ${stat.color}`} />
                </div>
                <p className={`font-display text-3xl font-extrabold ${stat.color}`}>
                  <AnimatedCounter target={stat.value} suffix={stat.suffix} />
                </p>
                <p className="text-sm text-muted-foreground font-medium">{stat.label}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* ── Features ───────────────────────────────────────────────────────── */}
      <section id="features" className="py-24">
        <div className="container">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={stagger}
            className="text-center mb-16"
          >
            <motion.div variants={fadeUp}>
              <span className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-secondary/10 text-secondary text-xs font-semibold border border-secondary/20 mb-4">
                <Zap className="w-3 h-3" /> Platform Features
              </span>
            </motion.div>
            <motion.h2 variants={fadeUp} className="font-display text-3xl md:text-4xl font-extrabold text-foreground mb-4">
              Everything You Need to{" "}
              <span className="gradient-text">Act on Climate</span>
            </motion.h2>
            <motion.p variants={fadeUp} className="text-muted-foreground max-w-2xl mx-auto text-lg">
              A complete climate intelligence ecosystem combining AI, real-time data, and community action.
            </motion.p>
          </motion.div>

          <motion.div
            variants={stagger}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid md:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            {features.map((f, i) => (
              <motion.div key={i} variants={fadeUp}>
                <Link to={f.path} className="glass-card p-6 block group hover:shadow-elevated transition-all duration-300 hover:-translate-y-1 h-full rounded-xl">
                  <div className={`w-12 h-12 rounded-2xl ${f.bg} flex items-center justify-center mb-4`}>
                    <f.icon className={`w-6 h-6 ${f.color}`} />
                  </div>
                  <h3 className="font-display font-bold text-lg text-foreground mb-2 group-hover:text-primary transition-colors">
                    {f.title}
                  </h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{f.description}</p>
                  <div className="mt-4 flex items-center gap-1 text-xs font-semibold text-primary opacity-0 group-hover:opacity-100 transition-opacity">
                    Explore <ChevronRight className="w-3 h-3" />
                  </div>
                </Link>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* ── How it works ───────────────────────────────────────────────────── */}
      <section className="py-24 bg-card/30 border-y border-border/60">
        <div className="container">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={stagger}
            className="text-center mb-16"
          >
            <motion.h2 variants={fadeUp} className="font-display text-3xl md:text-4xl font-extrabold text-foreground mb-4">
              How <span className="gradient-text">ClimateSense AI</span> Works
            </motion.h2>
            <motion.p variants={fadeUp} className="text-muted-foreground text-lg">
              Three simple steps to start your climate action journey.
            </motion.p>
          </motion.div>

          <motion.div
            variants={stagger}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid md:grid-cols-3 gap-8 relative"
          >
            {[
              {
                step: "01",
                icon: Calculator,
                title: "Calculate Your Footprint",
                desc: "Answer a few quick questions about your transportation, energy, food, and lifestyle habits.",
                color: "text-primary",
                bg: "bg-primary/10",
              },
              {
                step: "02",
                icon: Bell,
                title: "Get Personalized Alerts",
                desc: "Receive AI-powered climate risk alerts and sustainability insights tailored to your location.",
                color: "text-secondary",
                bg: "bg-secondary/10",
              },
              {
                step: "03",
                icon: Globe,
                title: "Take Climate Action",
                desc: "Join events, volunteer, and track your real-world impact with gamified rewards.",
                color: "text-primary",
                bg: "bg-primary/10",
              },
            ].map((step, i) => (
              <motion.div key={i} variants={fadeUp} className="relative flex flex-col items-center text-center gap-4">
                <div className="relative">
                  <div className={`w-16 h-16 rounded-2xl ${step.bg} flex items-center justify-center`}>
                    <step.icon className={`w-8 h-8 ${step.color}`} />
                  </div>
                  <span className="absolute -top-2 -right-2 w-7 h-7 rounded-full bg-primary text-primary-foreground text-xs font-bold flex items-center justify-center">
                    {i + 1}
                  </span>
                </div>
                <h3 className="font-display font-bold text-xl text-foreground">{step.title}</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">{step.desc}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* ── Events ─────────────────────────────────────────────────────────── */}
      <section id="events" className="py-24">
        <div className="container">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={stagger}
            className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-4"
          >
            <div>
              <motion.div variants={fadeUp}>
                <span className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-warning/10 text-warning text-xs font-semibold border border-warning/20 mb-4" style={{ color: "hsl(var(--warning))" }}>
                  <Calendar className="w-3 h-3" /> Upcoming Events
                </span>
              </motion.div>
              <motion.h2 variants={fadeUp} className="font-display text-3xl md:text-4xl font-extrabold text-foreground">
                Join Climate <span className="gradient-text">Action Events</span>
              </motion.h2>
            </div>
            <motion.div variants={fadeUp}>
              <Button asChild variant="outline" className="border-primary/30 text-primary hover:bg-primary/5">
                <Link to="/events">View All Events <ArrowRight className="w-4 h-4 ml-2" /></Link>
              </Button>
            </motion.div>
          </motion.div>

          <motion.div
            variants={stagger}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid md:grid-cols-2 gap-5"
          >
            {events.map((ev, i) => (
              <motion.div
                key={i}
                variants={fadeUp}
                className={`glass-card p-5 rounded-xl border-l-4 ${ev.color} hover:shadow-elevated transition-all duration-300 hover:-translate-y-0.5 cursor-pointer`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1">
                    <span className="inline-block px-2 py-0.5 rounded-full bg-muted text-muted-foreground text-xs font-medium mb-2">
                      {ev.category}
                    </span>
                    <h3 className="font-display font-bold text-foreground mb-1">{ev.title}</h3>
                    <div className="flex items-center gap-4 text-xs text-muted-foreground">
                      <span>📅 {ev.date}</span>
                      <span>📍 {ev.location}</span>
                    </div>
                  </div>
                  <div className="flex-shrink-0 text-right">
                    <p className="text-lg font-bold text-primary">{ev.volunteers}</p>
                    <p className="text-xs text-muted-foreground">volunteers</p>
                  </div>
                </div>
                <Button size="sm" className="mt-4 h-8 text-xs bg-primary/10 text-primary hover:bg-primary/20 border border-primary/20">
                  Register Now
                </Button>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* ── Testimonials ───────────────────────────────────────────────────── */}
      <section className="py-24 bg-card/30 border-y border-border/60">
        <div className="container">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={stagger}
            className="text-center mb-12"
          >
            <motion.h2 variants={fadeUp} className="font-display text-3xl font-extrabold text-foreground mb-3">
              Trusted by <span className="gradient-text">Climate Leaders</span>
            </motion.h2>
          </motion.div>

          <motion.div
            variants={stagger}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid md:grid-cols-3 gap-6"
          >
            {testimonials.map((t, i) => (
              <motion.div key={i} variants={fadeUp} className="glass-card p-6 rounded-xl">
                <div className="flex gap-0.5 mb-3">
                  {Array.from({ length: t.stars }).map((_, j) => (
                    <Star key={j} className="w-4 h-4 fill-warning text-warning" style={{ color: "hsl(var(--warning))" }} />
                  ))}
                </div>
                <p className="text-sm text-muted-foreground leading-relaxed mb-4">"{t.text}"</p>
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full bg-gradient-to-br from-primary/40 to-secondary/40 flex items-center justify-center text-sm font-bold text-foreground">
                    {t.avatar}
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-foreground">{t.name}</p>
                    <p className="text-xs text-muted-foreground">{t.role}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* ── CTA ────────────────────────────────────────────────────────────── */}
      <section className="py-24">
        <div className="container">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="relative rounded-3xl overflow-hidden p-12 md:p-16 text-center"
            style={{
              background: "linear-gradient(135deg, hsl(160 84% 39% / 0.12), hsl(199 89% 40% / 0.10))",
              border: "1px solid hsl(160 84% 39% / 0.2)",
            }}
          >
            <div className="absolute inset-0 pointer-events-none">
              <div className="absolute top-0 left-1/4 w-96 h-96 rounded-full bg-primary/5 blur-3xl" />
              <div className="absolute bottom-0 right-1/4 w-80 h-80 rounded-full bg-secondary/5 blur-3xl" />
            </div>
            <div className="relative">
              <Leaf className="w-12 h-12 text-primary mx-auto mb-6" />
              <h2 className="font-display text-3xl md:text-4xl font-extrabold text-foreground mb-4">
                Start Your Climate Action Journey <span className="gradient-text">Today</span>
              </h2>
              <p className="text-muted-foreground text-lg max-w-xl mx-auto mb-8">
                Join thousands of individuals and organizations already using ClimateSense AI to measure, reduce, and offset their environmental impact.
              </p>
              <div className="flex flex-wrap justify-center gap-4">
                <Button asChild size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90 shadow-glow-primary font-bold h-13 px-10">
                  <Link to="/dashboard">
                    Track Your Carbon Footprint
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Link>
                </Button>
                <Button asChild size="lg" variant="outline" className="h-13 px-10 font-bold border-primary/30 text-primary hover:bg-primary/5">
                  <Link to="/events">
                    Join Climate Action
                  </Link>
                </Button>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* ── Footer ─────────────────────────────────────────────────────────── */}
      <footer className="border-t border-border/60 py-12 bg-card/30">
        <div className="container flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-primary flex items-center justify-center">
              <Leaf className="w-4 h-4 text-primary-foreground" />
            </div>
            <span className="font-display font-bold text-lg">ClimateSense AI</span>
          </div>
          <p className="text-sm text-muted-foreground text-center">
            Supporting UN SDG 13 – Climate Action · Built for a sustainable future 🌍
          </p>
          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <a href="#" className="hover:text-foreground transition-colors">Privacy</a>
            <a href="#" className="hover:text-foreground transition-colors">Terms</a>
            <a href="#" className="hover:text-foreground transition-colors">Contact</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
