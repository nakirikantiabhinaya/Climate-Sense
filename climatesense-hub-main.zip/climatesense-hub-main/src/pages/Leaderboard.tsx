import { motion } from "framer-motion";
import { Trophy, Medal, Award, TrendingUp, Leaf, Users, TreePine, Star } from "lucide-react";
import DashboardLayout from "@/components/DashboardLayout";

const leaders = [
  { rank: 1, name: "Mei Lin Chen", location: "Singapore", score: 4850, trees: 312, events: 28, reduction: 67, avatar: "ML", badge: "🌟" },
  { rank: 2, name: "Carlos Mendez", location: "Barcelona", score: 4620, trees: 289, events: 24, reduction: 62, avatar: "CM", badge: "🏆" },
  { rank: 3, name: "Priya Sharma", location: "Mumbai", score: 4310, trees: 245, events: 21, reduction: 58, avatar: "PS", badge: "🥇" },
  { rank: 4, name: "Alex Johnson", location: "New York", score: 3890, trees: 198, events: 16, reduction: 43, avatar: "AJ", badge: "⭐", isUser: true },
  { rank: 5, name: "Emma Wagner", location: "Berlin", score: 3740, trees: 178, events: 15, reduction: 41, avatar: "EW", badge: "🌿" },
  { rank: 6, name: "Kenji Tanaka", location: "Tokyo", score: 3520, trees: 156, events: 13, reduction: 38, avatar: "KT", badge: "🌱" },
  { rank: 7, name: "Fatima Al-Hassan", location: "Dubai", score: 3290, trees: 134, events: 11, reduction: 35, avatar: "FA", badge: "💚" },
  { rank: 8, name: "Lucas Oliveira", location: "São Paulo", score: 3100, trees: 118, events: 10, reduction: 32, avatar: "LO", badge: "🌎" },
  { rank: 9, name: "Sophie Dubois", location: "Paris", score: 2870, trees: 102, events: 9, reduction: 29, avatar: "SD", badge: "🍀" },
  { rank: 10, name: "Aiko Nakamura", location: "Osaka", score: 2640, trees: 89, events: 8, reduction: 26, avatar: "AN", badge: "🌾" },
];

const badges = [
  { name: "Eco Beginner", icon: "🌱", desc: "First carbon calculation completed", earned: true, rarity: "Common" },
  { name: "Climate Warrior", icon: "⚡", desc: "Attended 10+ climate events", earned: true, rarity: "Uncommon" },
  { name: "Sustainability Champion", icon: "🏆", desc: "Sustainability score above 80", earned: true, rarity: "Rare" },
  { name: "CO₂ Crusher", icon: "📉", desc: "Reduced emissions by 20%+", earned: true, rarity: "Rare" },
  { name: "Green Leader", icon: "👑", desc: "Completed 100+ volunteer hours", earned: false, rarity: "Epic" },
  { name: "Community Hero", icon: "🤝", desc: "Organized 5+ climate events", earned: false, rarity: "Epic" },
  { name: "Earth Guardian", icon: "🌍", desc: "Top 100 global leaderboard", earned: false, rarity: "Legendary" },
  { name: "Carbon Neutral", icon: "⚖️", desc: "Achieved net-zero emissions", earned: false, rarity: "Legendary" },
];

const rarityColors: Record<string, string> = {
  Common: "text-muted-foreground bg-muted",
  Uncommon: "text-primary bg-primary/10",
  Rare: "text-secondary bg-secondary/10",
  Epic: "text-warning bg-warning/10",
  Legendary: "text-destructive bg-destructive/10",
};

export default function Leaderboard() {
  return (
    <DashboardLayout title="Leaderboard & Badges" subtitle="Global climate action rankings and achievement badges">
      {/* Top 3 podium */}
      <div className="grid grid-cols-3 gap-4 mb-8">
        {[leaders[1], leaders[0], leaders[2]].map((leader, i) => {
          const podium = [2, 1, 3];
          const heights = ["h-28", "h-36", "h-24"];
          const colors = ["border-secondary/40", "border-warning/60", "border-primary/40"];
          const bgColors = ["bg-secondary/5", "bg-warning/5", "bg-primary/5"];
          return (
            <motion.div
              key={leader.rank}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.15, duration: 0.5 }}
              className={`glass-card rounded-xl p-4 flex flex-col items-center text-center border-2 ${colors[i]} ${bgColors[i]}`}
            >
              <span className="text-2xl mb-2">{leader.badge}</span>
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary/30 to-secondary/30 border-2 border-primary/40 flex items-center justify-center font-bold text-foreground text-sm mb-2">
                {leader.avatar}
              </div>
              <p className="font-display font-bold text-sm text-foreground leading-tight">{leader.name}</p>
              <p className="text-xs text-muted-foreground">{leader.location}</p>
              <p className="font-display text-xl font-extrabold text-primary mt-2">{leader.score.toLocaleString()}</p>
              <p className="text-xs text-muted-foreground">impact pts</p>
              <div className={`mt-2 px-2 py-0.5 rounded-full text-xs font-bold ${i === 1 ? "bg-warning/20 text-warning" : i === 0 ? "bg-secondary/20 text-secondary" : "bg-primary/20 text-primary"}`}
                style={i === 1 ? { color: "hsl(var(--warning))" } : {}}>
                #{podium[i]}
              </div>
            </motion.div>
          );
        })}
      </div>

      <div className="grid lg:grid-cols-3 gap-5">
        {/* Full leaderboard */}
        <div className="lg:col-span-2 glass-card rounded-xl overflow-hidden">
          <div className="px-5 py-4 border-b border-border/60 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Trophy className="w-4.5 h-4.5 text-primary" />
              <h3 className="font-display font-bold text-foreground">Global Rankings</h3>
            </div>
            <span className="text-xs text-muted-foreground">1,247 participants</span>
          </div>
          <div className="divide-y divide-border/40">
            {leaders.map((leader, i) => (
              <motion.div
                key={leader.rank}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.05, duration: 0.35 }}
                className={`flex items-center gap-4 px-5 py-3.5 hover:bg-muted/30 transition-colors ${leader.isUser ? "bg-primary/5 border-l-2 border-primary" : ""}`}
              >
                <div className={`w-7 text-center font-display font-extrabold text-sm ${leader.rank <= 3 ? "text-primary" : "text-muted-foreground"}`}>
                  #{leader.rank}
                </div>
                <div className="w-9 h-9 rounded-full bg-gradient-to-br from-primary/20 to-secondary/20 border border-border flex items-center justify-center text-xs font-bold text-foreground flex-shrink-0">
                  {leader.avatar}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="font-semibold text-sm text-foreground truncate">{leader.name}</p>
                    {leader.isUser && <span className="text-xs bg-primary/10 text-primary px-1.5 py-0.5 rounded-full font-bold">You</span>}
                    <span className="text-base">{leader.badge}</span>
                  </div>
                  <p className="text-xs text-muted-foreground">{leader.location}</p>
                </div>
                <div className="hidden sm:grid grid-cols-3 gap-4 text-center">
                  <div>
                    <p className="text-xs font-bold text-primary">{leader.events}</p>
                    <p className="text-[10px] text-muted-foreground">events</p>
                  </div>
                  <div>
                    <p className="text-xs font-bold text-secondary">{leader.trees}</p>
                    <p className="text-[10px] text-muted-foreground">trees</p>
                  </div>
                  <div>
                    <p className="text-xs font-bold text-primary">-{leader.reduction}%</p>
                    <p className="text-[10px] text-muted-foreground">CO₂</p>
                  </div>
                </div>
                <div className="text-right flex-shrink-0">
                  <p className="font-display font-extrabold text-sm text-foreground">{leader.score.toLocaleString()}</p>
                  <p className="text-[10px] text-muted-foreground">pts</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Badges panel */}
        <div className="space-y-4">
          <div className="glass-card rounded-xl overflow-hidden">
            <div className="px-5 py-4 border-b border-border/60 flex items-center gap-2">
              <Award className="w-4.5 h-4.5 text-primary" />
              <h3 className="font-display font-bold text-foreground">Achievement Badges</h3>
            </div>
            <div className="p-4 grid grid-cols-2 gap-3">
              {badges.map((badge, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: i * 0.06, duration: 0.3 }}
                  className={`p-3 rounded-xl border text-center transition-all ${badge.earned ? "bg-card border-primary/20 hover:shadow-sm" : "opacity-40 bg-muted border-border"}`}
                >
                  <span className="text-2xl">{badge.icon}</span>
                  <p className="text-xs font-bold text-foreground mt-1 leading-tight">{badge.name}</p>
                  <p className="text-[10px] text-muted-foreground mt-0.5 leading-tight">{badge.desc}</p>
                  <span className={`inline-block mt-1.5 text-[9px] font-bold px-1.5 py-0.5 rounded-full ${rarityColors[badge.rarity]}`}
                    style={badge.rarity === "Epic" ? { color: "hsl(var(--warning))" } : {}}>
                    {badge.rarity}
                  </span>
                </motion.div>
              ))}
            </div>
          </div>

          {/* User rank summary */}
          <div className="glass-card p-4 rounded-xl border border-primary/20 bg-primary/5">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary/30 to-secondary/30 border-2 border-primary/40 flex items-center justify-center font-bold text-foreground">AJ</div>
              <div>
                <p className="font-display font-bold text-foreground text-sm">Alex Johnson</p>
                <p className="text-xs text-muted-foreground">Your ranking · New York</p>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-2">
              {[
                { label: "Global Rank", value: "#4", icon: Trophy },
                { label: "Impact Points", value: "3,890", icon: Star },
                { label: "Trees Planted", value: "198", icon: TreePine },
                { label: "CO₂ Reduction", value: "43%", icon: TrendingUp },
              ].map((m, i) => (
                <div key={i} className="bg-background/60 rounded-lg p-2.5 text-center">
                  <p className="font-display font-extrabold text-primary text-base">{m.value}</p>
                  <p className="text-[10px] text-muted-foreground">{m.label}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
