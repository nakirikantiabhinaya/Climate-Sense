import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Car, Zap, Utensils, ShoppingBag, ChevronRight,
  ChevronLeft, Check, Leaf, TrendingDown, Info, RotateCcw
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import DashboardLayout from "@/components/DashboardLayout";
import {
  PieChart, Pie, Cell, ResponsiveContainer, Tooltip
} from "recharts";

const steps = [
  { id: "transport", label: "Transportation", icon: Car, color: "text-secondary", bg: "bg-secondary/10" },
  { id: "energy", label: "Energy", icon: Zap, color: "text-warning", bg: "bg-warning/10" },
  { id: "food", label: "Food", icon: Utensils, color: "text-primary", bg: "bg-primary/10" },
  { id: "lifestyle", label: "Lifestyle", icon: ShoppingBag, color: "text-destructive", bg: "bg-destructive/10" },
];

interface Answers {
  carKm: number;
  flightHours: number;
  publicTransport: string;
  electricityKwh: number;
  acUsage: string;
  renewableEnergy: string;
  diet: string;
  dairyConsumption: string;
  shoppingFreq: string;
  wasteProduction: string;
}

const defaults: Answers = {
  carKm: 200,
  flightHours: 2,
  publicTransport: "sometimes",
  electricityKwh: 300,
  acUsage: "moderate",
  renewableEnergy: "no",
  diet: "mixed",
  dairyConsumption: "moderate",
  shoppingFreq: "moderate",
  wasteProduction: "average",
};

function calcEmissions(a: Answers) {
  const transport = a.carKm * 0.00021 * 4 + a.flightHours * 0.255 + (a.publicTransport === "never" ? 0.08 : a.publicTransport === "sometimes" ? 0.04 : 0.01);
  const energy = (a.electricityKwh * 0.00043 + (a.acUsage === "heavy" ? 0.15 : a.acUsage === "moderate" ? 0.08 : 0.03)) * (a.renewableEnergy === "yes" ? 0.4 : 1);
  const food = a.diet === "vegan" ? 0.08 : a.diet === "vegetarian" ? 0.12 : a.diet === "mixed" ? 0.2 : 0.28;
  const lifestyle = a.shoppingFreq === "heavy" ? 0.18 : a.shoppingFreq === "moderate" ? 0.1 : 0.05;
  return { transport: +transport.toFixed(2), energy: +energy.toFixed(2), food: +food.toFixed(2), lifestyle: +lifestyle.toFixed(2) };
}

const tips = [
  "🚗 Switch to electric or hybrid vehicle to cut transport emissions by 50%",
  "⚡ Install solar panels — renewables can cut energy emissions by 60%",
  "🥗 Reducing meat consumption to once a week cuts food emissions significantly",
  "🛍️ Buy second-hand and repair items instead of buying new",
  "🚲 Cycle or walk for trips under 5km",
  "🏠 Improve home insulation to reduce heating/cooling needs by up to 30%",
];

export default function Calculator() {
  const [step, setStep] = useState(0);
  const [answers, setAnswers] = useState<Answers>(defaults);
  const [completed, setCompleted] = useState(false);

  const emissions = calcEmissions(answers);
  const total = +(emissions.transport + emissions.energy + emissions.food + emissions.lifestyle).toFixed(2);

  const pieData = [
    { name: "Transport", value: emissions.transport, color: "#0284C7" },
    { name: "Energy", value: emissions.energy, color: "#F59E0B" },
    { name: "Food", value: emissions.food, color: "#10B981" },
    { name: "Lifestyle", value: emissions.lifestyle, color: "#EF4444" },
  ];

  const score = total < 1.5 ? "Excellent" : total < 2.5 ? "Good" : total < 3.5 ? "Moderate" : "High";
  const scoreColor = total < 1.5 ? "text-primary" : total < 2.5 ? "text-primary" : total < 3.5 ? "text-warning" : "text-destructive";

  return (
    <DashboardLayout title="Carbon Footprint Calculator" subtitle="Estimate and track your monthly carbon emissions">
      {/* Step indicator */}
      <div className="flex items-center gap-2 mb-8">
        {steps.map((s, i) => (
          <div key={s.id} className="flex items-center gap-2">
            <div
              className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-semibold transition-all cursor-pointer ${
                i === step && !completed
                  ? "bg-primary text-primary-foreground"
                  : i < step || completed
                  ? "bg-primary/20 text-primary"
                  : "bg-muted text-muted-foreground"
              }`}
              onClick={() => { setCompleted(false); setStep(i); }}
            >
              {(i < step || completed) ? <Check className="w-3 h-3" /> : <s.icon className="w-3 h-3" />}
              <span className="hidden sm:block">{s.label}</span>
            </div>
            {i < steps.length - 1 && <ChevronRight className="w-3 h-3 text-muted-foreground" />}
          </div>
        ))}
        {completed && (
          <div className="flex items-center gap-2">
            <ChevronRight className="w-3 h-3 text-muted-foreground" />
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-semibold bg-primary text-primary-foreground">
              <Leaf className="w-3 h-3" /> Results
            </div>
          </div>
        )}
      </div>

      <div className="grid lg:grid-cols-5 gap-6">
        {/* Form */}
        <div className="lg:col-span-3">
          <AnimatePresence mode="wait">
            {!completed ? (
              <motion.div
                key={step}
                initial={{ opacity: 0, x: 30 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -30 }}
                transition={{ duration: 0.3 }}
                className="glass-card p-6 rounded-xl"
              >
                {/* Transport step */}
                {step === 0 && (
                  <div className="space-y-6">
                    <div className="flex items-center gap-3 mb-6">
                      <div className="w-10 h-10 rounded-xl bg-secondary/10 flex items-center justify-center">
                        <Car className="w-5 h-5 text-secondary" />
                      </div>
                      <div>
                        <h3 className="font-display font-bold text-foreground">Transportation</h3>
                        <p className="text-xs text-muted-foreground">Monthly travel patterns</p>
                      </div>
                    </div>
                    <div>
                      <Label className="text-sm font-semibold text-foreground mb-3 block">
                        Car distance per month: <span className="text-primary">{answers.carKm} km</span>
                      </Label>
                      <Slider
                        min={0} max={2000} step={50}
                        value={[answers.carKm]}
                        onValueChange={([v]) => setAnswers({ ...answers, carKm: v })}
                        className="mt-2"
                      />
                      <div className="flex justify-between text-xs text-muted-foreground mt-1">
                        <span>0 km</span><span>2,000 km</span>
                      </div>
                    </div>
                    <div>
                      <Label className="text-sm font-semibold text-foreground mb-3 block">
                        Flights per month: <span className="text-primary">{answers.flightHours} hrs</span>
                      </Label>
                      <Slider
                        min={0} max={40} step={1}
                        value={[answers.flightHours]}
                        onValueChange={([v]) => setAnswers({ ...answers, flightHours: v })}
                      />
                      <div className="flex justify-between text-xs text-muted-foreground mt-1">
                        <span>0 hrs</span><span>40 hrs</span>
                      </div>
                    </div>
                    <div>
                      <Label className="text-sm font-semibold text-foreground mb-3 block">Public transport usage</Label>
                      <RadioGroup
                        value={answers.publicTransport}
                        onValueChange={(v) => setAnswers({ ...answers, publicTransport: v })}
                        className="grid grid-cols-3 gap-2"
                      >
                        {["never", "sometimes", "always"].map((v) => (
                          <div key={v} className={`flex items-center gap-2 p-3 rounded-lg border cursor-pointer transition-all ${answers.publicTransport === v ? "border-primary bg-primary/5" : "border-border hover:border-primary/40"}`}>
                            <RadioGroupItem value={v} id={`pt-${v}`} />
                            <Label htmlFor={`pt-${v}`} className="text-xs capitalize cursor-pointer">{v}</Label>
                          </div>
                        ))}
                      </RadioGroup>
                    </div>
                  </div>
                )}

                {/* Energy step */}
                {step === 1 && (
                  <div className="space-y-6">
                    <div className="flex items-center gap-3 mb-6">
                      <div className="w-10 h-10 rounded-xl bg-warning/10 flex items-center justify-center">
                        <Zap className="w-5 h-5 text-warning" style={{ color: "hsl(var(--warning))" }} />
                      </div>
                      <div>
                        <h3 className="font-display font-bold text-foreground">Energy Usage</h3>
                        <p className="text-xs text-muted-foreground">Home energy consumption</p>
                      </div>
                    </div>
                    <div>
                      <Label className="text-sm font-semibold text-foreground mb-3 block">
                        Monthly electricity: <span className="text-primary">{answers.electricityKwh} kWh</span>
                      </Label>
                      <Slider
                        min={50} max={1000} step={25}
                        value={[answers.electricityKwh]}
                        onValueChange={([v]) => setAnswers({ ...answers, electricityKwh: v })}
                      />
                      <div className="flex justify-between text-xs text-muted-foreground mt-1">
                        <span>50 kWh</span><span>1,000 kWh</span>
                      </div>
                    </div>
                    <div>
                      <Label className="text-sm font-semibold text-foreground mb-3 block">Air conditioning usage</Label>
                      <RadioGroup
                        value={answers.acUsage}
                        onValueChange={(v) => setAnswers({ ...answers, acUsage: v })}
                        className="grid grid-cols-3 gap-2"
                      >
                        {["light", "moderate", "heavy"].map((v) => (
                          <div key={v} className={`flex items-center gap-2 p-3 rounded-lg border cursor-pointer transition-all ${answers.acUsage === v ? "border-primary bg-primary/5" : "border-border hover:border-primary/40"}`}>
                            <RadioGroupItem value={v} id={`ac-${v}`} />
                            <Label htmlFor={`ac-${v}`} className="text-xs capitalize cursor-pointer">{v}</Label>
                          </div>
                        ))}
                      </RadioGroup>
                    </div>
                    <div>
                      <Label className="text-sm font-semibold text-foreground mb-3 block">Using renewable energy?</Label>
                      <RadioGroup
                        value={answers.renewableEnergy}
                        onValueChange={(v) => setAnswers({ ...answers, renewableEnergy: v })}
                        className="grid grid-cols-2 gap-2"
                      >
                        {["yes", "no"].map((v) => (
                          <div key={v} className={`flex items-center gap-2 p-3 rounded-lg border cursor-pointer transition-all ${answers.renewableEnergy === v ? "border-primary bg-primary/5" : "border-border hover:border-primary/40"}`}>
                            <RadioGroupItem value={v} id={`re-${v}`} />
                            <Label htmlFor={`re-${v}`} className="text-xs capitalize cursor-pointer">{v === "yes" ? "Yes – Solar/Wind" : "No – Grid Power"}</Label>
                          </div>
                        ))}
                      </RadioGroup>
                    </div>
                  </div>
                )}

                {/* Food step */}
                {step === 2 && (
                  <div className="space-y-6">
                    <div className="flex items-center gap-3 mb-6">
                      <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
                        <Utensils className="w-5 h-5 text-primary" />
                      </div>
                      <div>
                        <h3 className="font-display font-bold text-foreground">Diet & Food</h3>
                        <p className="text-xs text-muted-foreground">Food choices impact</p>
                      </div>
                    </div>
                    <div>
                      <Label className="text-sm font-semibold text-foreground mb-3 block">Primary diet type</Label>
                      <RadioGroup
                        value={answers.diet}
                        onValueChange={(v) => setAnswers({ ...answers, diet: v })}
                        className="grid grid-cols-2 gap-2"
                      >
                        {[
                          { value: "vegan", label: "🌱 Vegan" },
                          { value: "vegetarian", label: "🥦 Vegetarian" },
                          { value: "mixed", label: "🍽️ Mixed" },
                          { value: "meat_heavy", label: "🥩 Meat-heavy" },
                        ].map((opt) => (
                          <div key={opt.value} className={`flex items-center gap-2 p-3 rounded-lg border cursor-pointer transition-all ${answers.diet === opt.value ? "border-primary bg-primary/5" : "border-border hover:border-primary/40"}`}>
                            <RadioGroupItem value={opt.value} id={`diet-${opt.value}`} />
                            <Label htmlFor={`diet-${opt.value}`} className="text-xs cursor-pointer">{opt.label}</Label>
                          </div>
                        ))}
                      </RadioGroup>
                    </div>
                    <div>
                      <Label className="text-sm font-semibold text-foreground mb-3 block">Dairy consumption</Label>
                      <RadioGroup
                        value={answers.dairyConsumption}
                        onValueChange={(v) => setAnswers({ ...answers, dairyConsumption: v })}
                        className="grid grid-cols-3 gap-2"
                      >
                        {["low", "moderate", "high"].map((v) => (
                          <div key={v} className={`flex items-center gap-2 p-3 rounded-lg border cursor-pointer transition-all ${answers.dairyConsumption === v ? "border-primary bg-primary/5" : "border-border hover:border-primary/40"}`}>
                            <RadioGroupItem value={v} id={`dairy-${v}`} />
                            <Label htmlFor={`dairy-${v}`} className="text-xs capitalize cursor-pointer">{v}</Label>
                          </div>
                        ))}
                      </RadioGroup>
                    </div>
                  </div>
                )}

                {/* Lifestyle step */}
                {step === 3 && (
                  <div className="space-y-6">
                    <div className="flex items-center gap-3 mb-6">
                      <div className="w-10 h-10 rounded-xl bg-destructive/10 flex items-center justify-center">
                        <ShoppingBag className="w-5 h-5 text-destructive" />
                      </div>
                      <div>
                        <h3 className="font-display font-bold text-foreground">Lifestyle & Shopping</h3>
                        <p className="text-xs text-muted-foreground">Consumer habits</p>
                      </div>
                    </div>
                    <div>
                      <Label className="text-sm font-semibold text-foreground mb-3 block">Shopping frequency</Label>
                      <RadioGroup
                        value={answers.shoppingFreq}
                        onValueChange={(v) => setAnswers({ ...answers, shoppingFreq: v })}
                        className="grid grid-cols-3 gap-2"
                      >
                        {[
                          { value: "minimal", label: "🌿 Minimal" },
                          { value: "moderate", label: "🛍️ Moderate" },
                          { value: "heavy", label: "🏷️ Heavy" },
                        ].map((opt) => (
                          <div key={opt.value} className={`flex items-center gap-2 p-3 rounded-lg border cursor-pointer transition-all ${answers.shoppingFreq === opt.value ? "border-primary bg-primary/5" : "border-border hover:border-primary/40"}`}>
                            <RadioGroupItem value={opt.value} id={`shop-${opt.value}`} />
                            <Label htmlFor={`shop-${opt.value}`} className="text-xs cursor-pointer">{opt.label}</Label>
                          </div>
                        ))}
                      </RadioGroup>
                    </div>
                    <div>
                      <Label className="text-sm font-semibold text-foreground mb-3 block">Waste production</Label>
                      <RadioGroup
                        value={answers.wasteProduction}
                        onValueChange={(v) => setAnswers({ ...answers, wasteProduction: v })}
                        className="grid grid-cols-3 gap-2"
                      >
                        {["low", "average", "high"].map((v) => (
                          <div key={v} className={`flex items-center gap-2 p-3 rounded-lg border cursor-pointer transition-all ${answers.wasteProduction === v ? "border-primary bg-primary/5" : "border-border hover:border-primary/40"}`}>
                            <RadioGroupItem value={v} id={`waste-${v}`} />
                            <Label htmlFor={`waste-${v}`} className="text-xs capitalize cursor-pointer">{v}</Label>
                          </div>
                        ))}
                      </RadioGroup>
                    </div>
                  </div>
                )}

                {/* Nav buttons */}
                <div className="flex justify-between mt-8 pt-5 border-t border-border/60">
                  <Button
                    variant="ghost"
                    onClick={() => step > 0 && setStep(step - 1)}
                    disabled={step === 0}
                    className="text-muted-foreground"
                  >
                    <ChevronLeft className="w-4 h-4 mr-1" /> Back
                  </Button>
                  {step < steps.length - 1 ? (
                    <Button onClick={() => setStep(step + 1)} className="bg-primary text-primary-foreground hover:bg-primary/90">
                      Next <ChevronRight className="w-4 h-4 ml-1" />
                    </Button>
                  ) : (
                    <Button onClick={() => setCompleted(true)} className="bg-primary text-primary-foreground hover:bg-primary/90 shadow-glow-primary">
                      <Leaf className="w-4 h-4 mr-2" /> Calculate Results
                    </Button>
                  )}
                </div>
              </motion.div>
            ) : (
              <motion.div
                key="results"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.4 }}
                className="glass-card p-6 rounded-xl"
              >
                <div className="text-center mb-6">
                  <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
                    <Leaf className="w-8 h-8 text-primary" />
                  </div>
                  <h3 className="font-display text-2xl font-extrabold text-foreground">Your Carbon Footprint</h3>
                  <p className="text-muted-foreground text-sm mt-1">Monthly emissions estimate</p>
                </div>
                <div className="text-center mb-6">
                  <p className={`font-display text-6xl font-extrabold ${scoreColor}`}>{total}</p>
                  <p className="text-lg text-muted-foreground font-medium">tonnes CO₂ / month</p>
                  <span className={`inline-block mt-2 px-3 py-1 rounded-full text-sm font-bold ${scoreColor} bg-primary/10`}>
                    {score} Impact
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-3 mb-6">
                  {pieData.map((cat, i) => (
                    <div key={i} className="flex items-center justify-between p-3 rounded-lg bg-muted/50 text-sm">
                      <div className="flex items-center gap-2">
                        <div className="w-2.5 h-2.5 rounded-full" style={{ background: cat.color }} />
                        <span className="text-muted-foreground">{cat.name}</span>
                      </div>
                      <span className="font-bold text-foreground">{cat.value}t</span>
                    </div>
                  ))}
                </div>

                <div className="p-4 rounded-xl bg-primary/5 border border-primary/20">
                  <p className="text-xs font-semibold text-foreground mb-1">Annual equivalent:</p>
                  <p className="text-2xl font-extrabold text-primary font-display">{(total * 12).toFixed(1)} t CO₂/year</p>
                  <p className="text-xs text-muted-foreground mt-1">Global avg: 4.8t/year • Paris target: &lt;2t/year</p>
                </div>

                <Button
                  onClick={() => { setCompleted(false); setStep(0); setAnswers(defaults); }}
                  variant="outline"
                  className="w-full mt-4 border-primary/30 text-primary hover:bg-primary/5"
                >
                  <RotateCcw className="w-4 h-4 mr-2" /> Recalculate
                </Button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Right panel */}
        <div className="lg:col-span-2 space-y-5">
          {/* Live preview */}
          <div className="glass-card p-5 rounded-xl">
            <h4 className="font-display font-bold text-foreground mb-4">Live Preview</h4>
            <div className="text-center mb-2">
              <p className={`font-display text-4xl font-extrabold ${scoreColor}`}>{total}</p>
              <p className="text-sm text-muted-foreground">t CO₂/month</p>
            </div>
            <ResponsiveContainer width="100%" height={160}>
              <PieChart>
                <Pie data={pieData} cx="50%" cy="50%" outerRadius={65} paddingAngle={3} dataKey="value">
                  {pieData.map((entry, i) => (
                    <Cell key={i} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip formatter={(val) => [`${val}t`, ""]} contentStyle={{ borderRadius: 8, fontSize: 12 }} />
              </PieChart>
            </ResponsiveContainer>
            <div className="grid grid-cols-2 gap-2 mt-2">
              {pieData.map((cat, i) => (
                <div key={i} className="flex items-center gap-2 text-xs">
                  <div className="w-2 h-2 rounded-full" style={{ background: cat.color }} />
                  <span className="text-muted-foreground">{cat.name}</span>
                  <span className="font-semibold text-foreground ml-auto">{cat.value}t</span>
                </div>
              ))}
            </div>
          </div>

          {/* Tips */}
          <div className="glass-card p-5 rounded-xl">
            <div className="flex items-center gap-2 mb-4">
              <Info className="w-4 h-4 text-primary" />
              <h4 className="font-display font-bold text-foreground">Reduction Tips</h4>
            </div>
            <div className="space-y-2">
              {tips.slice(0, 4).map((tip, i) => (
                <p key={i} className="text-xs text-muted-foreground p-2 rounded-lg bg-muted/50 leading-relaxed">{tip}</p>
              ))}
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
