import { motion } from "framer-motion";
import { AlertTriangle, Wind, Thermometer, Droplets, Eye, MapPin, RefreshCw, Shield } from "lucide-react";
import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";

const alerts = [
  {
    id: 1,
    type: "high",
    category: "Heatwave",
    icon: Thermometer,
    title: "Extreme Heatwave Warning",
    desc: "Temperature expected to reach 44°C over the next 48 hours. High risk of heat stroke. Avoid outdoor activities between 11AM–5PM.",
    location: "Mumbai, India",
    time: "Active Now",
    advice: ["Stay hydrated — drink 3-4L water daily", "Stay indoors with cooling", "Check on elderly neighbors"],
    color: "text-destructive",
    bgColor: "bg-destructive/8",
    borderColor: "border-destructive/30",
    badgeColor: "bg-destructive/10 text-destructive",
  },
  {
    id: 2,
    type: "high",
    category: "Air Quality",
    icon: Wind,
    title: "Hazardous Air Quality Alert",
    desc: "AQI has reached 178 (Unhealthy). Fine particulate matter (PM2.5) levels are dangerously elevated due to wildfires.",
    location: "Los Angeles, CA",
    time: "Since 6:00 AM",
    advice: ["Wear N95 mask outdoors", "Keep windows closed", "Run air purifiers indoors"],
    color: "text-destructive",
    bgColor: "bg-destructive/8",
    borderColor: "border-destructive/30",
    badgeColor: "bg-destructive/10 text-destructive",
  },
  {
    id: 3,
    type: "medium",
    category: "Heavy Rainfall",
    icon: Droplets,
    title: "Flood Watch Issued",
    desc: "Rainfall of 80–120mm expected in the next 24 hours. Low-lying areas may experience flooding. Monitor local updates.",
    location: "Chennai, India",
    time: "Next 24 hours",
    advice: ["Avoid low-lying areas", "Prepare emergency kit", "Keep vehicle tanks full"],
    color: "text-warning",
    bgColor: "bg-warning/8",
    borderColor: "border-warning/30",
    badgeColor: "bg-warning/10",
  },
  {
    id: 4,
    type: "medium",
    category: "UV Index",
    icon: Eye,
    title: "Very High UV Index — Level 9",
    desc: "UV radiation is at very high levels. Unprotected skin can be damaged in as little as 15 minutes of sun exposure.",
    location: "Sydney, Australia",
    time: "10:00 AM – 4:00 PM",
    advice: ["Apply SPF 50+ sunscreen", "Wear UV-protective clothing", "Seek shade during peak hours"],
    color: "text-warning",
    bgColor: "bg-warning/8",
    borderColor: "border-warning/30",
    badgeColor: "bg-warning/10",
  },
  {
    id: 5,
    type: "low",
    category: "Wind Advisory",
    icon: Wind,
    title: "Strong Wind Advisory",
    desc: "Wind gusts up to 60 km/h expected throughout the day. Possible tree branches down and minor property damage.",
    location: "Chicago, IL",
    time: "Until 8:00 PM",
    advice: ["Secure outdoor furniture", "Drive carefully on highways", "Avoid cycling outdoors"],
    color: "text-primary",
    bgColor: "bg-primary/8",
    borderColor: "border-primary/30",
    badgeColor: "bg-primary/10 text-primary",
  },
];

const riskSummary = [
  { level: "Extreme", count: 0, color: "bg-destructive" },
  { level: "High", count: 2, color: "bg-orange-500" },
  { level: "Medium", count: 2, color: "bg-warning" },
  { level: "Low", count: 1, color: "bg-primary" },
];

export default function Alerts() {
  return (
    <DashboardLayout title="Climate Risk Alerts" subtitle="Real-time environmental risk alerts for your locations">
      {/* Risk overview */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        {riskSummary.map((r, i) => (
          <div key={i} className="glass-card p-4 rounded-xl">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-muted-foreground font-medium">{r.level} Risk</span>
              <div className={`w-2.5 h-2.5 rounded-full ${r.color} ${r.count > 0 ? "animate-pulse" : "opacity-30"}`} />
            </div>
            <p className="font-display text-3xl font-extrabold text-foreground">{r.count}</p>
            <p className="text-xs text-muted-foreground">active alerts</p>
          </div>
        ))}
      </div>

      {/* Header actions */}
      <div className="flex items-center justify-between mb-5">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20">
            <MapPin className="w-3 h-3 text-primary" />
            <span className="text-xs font-semibold text-primary">3 Locations Monitored</span>
          </div>
        </div>
        <Button variant="outline" size="sm" className="border-border text-muted-foreground hover:text-foreground gap-2">
          <RefreshCw className="w-3.5 h-3.5" /> Refresh Alerts
        </Button>
      </div>

      {/* Alerts list */}
      <div className="space-y-4">
        {alerts.map((alert, i) => (
          <motion.div
            key={alert.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.08, duration: 0.4 }}
            className={`rounded-xl border-l-4 border ${alert.borderColor} ${alert.bgColor} p-5`}
          >
            <div className="flex flex-col md:flex-row md:items-start gap-4">
              <div className="flex items-center gap-4 flex-1">
                <div className={`w-12 h-12 rounded-xl flex-shrink-0 flex items-center justify-center ${alert.type === 'high' ? 'bg-destructive/15' : alert.type === 'medium' ? 'bg-warning/15' : 'bg-primary/10'}`}>
                  <alert.icon className={`w-6 h-6 ${alert.color}`} style={alert.type === 'medium' ? { color: 'hsl(var(--warning))' } : {}} />
                </div>
                <div className="flex-1">
                  <div className="flex flex-wrap items-center gap-2 mb-1">
                    <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${alert.badgeColor}`} style={alert.type === 'medium' ? { color: 'hsl(var(--warning))' } : {}}>
                      {alert.category}
                    </span>
                    {alert.type === "high" && (
                      <span className="flex items-center gap-1 text-xs text-destructive font-semibold">
                        <AlertTriangle className="w-3 h-3" /> High Risk
                      </span>
                    )}
                    <span className="text-xs text-muted-foreground">⏱ {alert.time}</span>
                  </div>
                  <h3 className="font-display font-bold text-foreground text-base">{alert.title}</h3>
                  <p className="text-sm text-muted-foreground mt-1 leading-relaxed">{alert.desc}</p>
                  <div className="flex items-center gap-1.5 mt-2 text-xs text-muted-foreground">
                    <MapPin className="w-3 h-3" />
                    {alert.location}
                  </div>
                </div>
              </div>

              {/* Safety advice */}
              <div className="flex-shrink-0 md:w-52">
                <div className="p-3 rounded-lg bg-card/60 border border-border/40">
                  <div className="flex items-center gap-2 mb-2">
                    <Shield className="w-3.5 h-3.5 text-primary" />
                    <p className="text-xs font-bold text-foreground">Safety Advice</p>
                  </div>
                  <ul className="space-y-1.5">
                    {alert.advice.map((tip, j) => (
                      <li key={j} className="text-xs text-muted-foreground flex items-start gap-1.5">
                        <span className="text-primary mt-0.5">•</span>
                        {tip}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Info panel */}
      <div className="glass-card p-5 rounded-xl mt-6 border-l-4 border-l-secondary">
        <div className="flex items-start gap-4">
          <div className="w-10 h-10 rounded-xl bg-secondary/10 flex items-center justify-center flex-shrink-0">
            <MapPin className="w-5 h-5 text-secondary" />
          </div>
          <div>
            <h4 className="font-display font-bold text-foreground mb-1">Add More Locations</h4>
            <p className="text-sm text-muted-foreground">Monitor climate risks for your home, office, or any location globally. Get alerts for heatwaves, air quality, floods, and more.</p>
            <Button size="sm" className="mt-3 bg-secondary text-secondary-foreground hover:bg-secondary/90">
              + Add Location
            </Button>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
