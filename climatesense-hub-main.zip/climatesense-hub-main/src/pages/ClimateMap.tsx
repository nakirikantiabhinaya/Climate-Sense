import { MapPin, Layers, Filter, AlertTriangle, Calendar, Users, Navigation } from "lucide-react";
import { Button } from "@/components/ui/button";
import DashboardLayout from "@/components/DashboardLayout";

const mapMarkers = [
  { id: 1, type: "event", label: "Tree Plantation Drive", location: "Central Park, NY", date: "Mar 22", x: 62, y: 38, color: "bg-primary" },
  { id: 2, type: "alert", label: "Heatwave Warning", location: "Phoenix, AZ", date: "Active", x: 24, y: 52, color: "bg-destructive" },
  { id: 3, type: "event", label: "Beach Cleanup", location: "Marina Beach, CA", date: "Mar 28", x: 10, y: 46, color: "bg-secondary" },
  { id: 4, type: "alert", label: "Air Quality Alert", location: "Houston, TX", date: "Active", x: 34, y: 60, color: "bg-warning" },
  { id: 5, type: "event", label: "Climate Workshop", location: "Chicago, IL", date: "Apr 5", x: 52, y: 36, color: "bg-primary" },
  { id: 6, type: "alert", label: "Flood Watch", location: "New Orleans, LA", date: "Active", x: 45, y: 65, color: "bg-destructive" },
  { id: 7, type: "event", label: "Zero Waste Day", location: "Seattle, WA", date: "Apr 12", x: 10, y: 28, color: "bg-primary" },
];

const legend = [
  { color: "bg-primary", label: "Climate Events" },
  { color: "bg-destructive", label: "High Risk Alert" },
  { color: "bg-warning", label: "Moderate Alert" },
  { color: "bg-secondary", label: "Active Cleanup" },
];

export default function ClimateMap() {
  return (
    <DashboardLayout title="Climate Action Map" subtitle="Visualize events, risk zones, and environmental activities worldwide">
      {/* Filter bar */}
      <div className="flex flex-wrap gap-3 mb-5">
        <Button variant="outline" size="sm" className="gap-2 border-border text-muted-foreground hover:text-foreground">
          <Filter className="w-3.5 h-3.5" /> All Types
        </Button>
        {["Events", "Risk Zones", "Cleanups", "Plantations"].map((f) => (
          <Button key={f} variant="outline" size="sm" className="border-border text-muted-foreground hover:border-primary/40 hover:text-primary">
            {f}
          </Button>
        ))}
        <div className="ml-auto">
          <Button size="sm" className="bg-primary text-primary-foreground hover:bg-primary/90 gap-2">
            <Navigation className="w-3.5 h-3.5" /> My Location
          </Button>
        </div>
      </div>

      <div className="grid lg:grid-cols-4 gap-5">
        {/* Map panel */}
        <div className="lg:col-span-3">
          <div className="glass-card rounded-xl overflow-hidden relative" style={{ height: 480 }}>
            {/* Map background — stylized SVG grid */}
            <div className="absolute inset-0 bg-gradient-to-br from-secondary/5 via-background to-primary/5">
              {/* Grid lines */}
              <svg className="absolute inset-0 w-full h-full opacity-20" xmlns="http://www.w3.org/2000/svg">
                <defs>
                  <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                    <path d="M 40 0 L 0 0 0 40" fill="none" stroke="hsl(160 84% 39%)" strokeWidth="0.5" />
                  </pattern>
                </defs>
                <rect width="100%" height="100%" fill="url(#grid)" />
              </svg>
              {/* Continent blobs */}
              <svg className="absolute inset-0 w-full h-full opacity-10" viewBox="0 0 100 60" preserveAspectRatio="xMidYMid slice">
                <ellipse cx="20" cy="30" rx="12" ry="18" fill="hsl(199 89% 40%)" />
                <ellipse cx="45" cy="25" rx="22" ry="14" fill="hsl(160 84% 39%)" />
                <ellipse cx="72" cy="28" rx="18" ry="16" fill="hsl(199 89% 40%)" />
                <ellipse cx="55" cy="45" rx="8" ry="5" fill="hsl(160 84% 39%)" />
                <ellipse cx="85" cy="38" rx="7" ry="9" fill="hsl(199 89% 40%)" />
              </svg>
            </div>

            {/* Markers */}
            {mapMarkers.map((marker) => (
              <div
                key={marker.id}
                className="absolute group cursor-pointer"
                style={{ left: `${marker.x}%`, top: `${marker.y}%`, transform: "translate(-50%, -50%)" }}
              >
                {/* Pulse ring */}
                {marker.type === "alert" && (
                  <div className={`absolute inset-0 rounded-full ${marker.color} opacity-30 animate-ping scale-150`} />
                )}
                {/* Pin */}
                <div className={`w-7 h-7 rounded-full ${marker.color} flex items-center justify-center shadow-elevated border-2 border-background z-10 relative`}>
                  {marker.type === "alert"
                    ? <AlertTriangle className="w-3.5 h-3.5 text-white" />
                    : <MapPin className="w-3.5 h-3.5 text-white" />
                  }
                </div>
                {/* Tooltip */}
                <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 opacity-0 group-hover:opacity-100 transition-all duration-200 pointer-events-none z-20 whitespace-nowrap">
                  <div className="bg-card border border-border shadow-elevated rounded-lg px-3 py-2 text-xs">
                    <p className="font-bold text-foreground">{marker.label}</p>
                    <p className="text-muted-foreground">{marker.location}</p>
                    <p className="text-primary font-semibold">{marker.date}</p>
                  </div>
                </div>
              </div>
            ))}

            {/* Legend */}
            <div className="absolute bottom-4 left-4 glass-card p-3 rounded-xl border border-border/60">
              <p className="text-xs font-bold text-foreground mb-2">Legend</p>
              <div className="space-y-1.5">
                {legend.map((l, i) => (
                  <div key={i} className="flex items-center gap-2 text-xs text-muted-foreground">
                    <div className={`w-3 h-3 rounded-full ${l.color} flex-shrink-0`} />
                    {l.label}
                  </div>
                ))}
              </div>
            </div>

            {/* Zoom controls */}
            <div className="absolute top-4 right-4 flex flex-col gap-1">
              {["+", "−"].map((c) => (
                <button key={c} className="w-8 h-8 glass-card rounded-lg border border-border/60 flex items-center justify-center text-sm font-bold text-foreground hover:bg-muted transition-all">
                  {c}
                </button>
              ))}
            </div>

            {/* Map credit */}
            <div className="absolute bottom-4 right-4 text-[10px] text-muted-foreground/60">
              ClimateSense AI Map · Demo View
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-4">
          <div className="glass-card p-4 rounded-xl">
            <div className="flex items-center gap-2 mb-3">
              <Layers className="w-4 h-4 text-primary" />
              <h4 className="font-display font-bold text-sm text-foreground">Map Layers</h4>
            </div>
            <div className="space-y-2">
              {["Climate Events", "Risk Zones", "Air Quality", "Temperature", "Rainfall"].map((layer) => (
                <label key={layer} className="flex items-center gap-2.5 cursor-pointer">
                  <input type="checkbox" defaultChecked={layer !== "Rainfall"} className="rounded accent-primary" />
                  <span className="text-xs text-muted-foreground">{layer}</span>
                </label>
              ))}
            </div>
          </div>

          <div className="glass-card p-4 rounded-xl">
            <div className="flex items-center gap-2 mb-3">
              <MapPin className="w-4 h-4 text-primary" />
              <h4 className="font-display font-bold text-sm text-foreground">Nearby Activity</h4>
            </div>
            <div className="space-y-3">
              {mapMarkers.slice(0, 4).map((m, i) => (
                <div key={i} className="flex items-center gap-3 p-2.5 rounded-lg bg-muted/50 hover:bg-muted transition-colors cursor-pointer">
                  <div className={`w-2 h-2 rounded-full ${m.color} flex-shrink-0 ${m.type === "alert" ? "animate-pulse" : ""}`} />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-semibold text-foreground truncate">{m.label}</p>
                    <p className="text-[10px] text-muted-foreground truncate">{m.location}</p>
                  </div>
                  <span className="text-[10px] text-muted-foreground flex-shrink-0">{m.date}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="glass-card p-4 rounded-xl">
            <div className="flex items-center gap-2 mb-2">
              <Users className="w-4 h-4 text-secondary" />
              <h4 className="font-display font-bold text-sm text-foreground">Map Stats</h4>
            </div>
            {[
              { label: "Active Events", value: "47", color: "text-primary" },
              { label: "Risk Alerts", value: "12", color: "text-destructive" },
              { label: "Volunteers Active", value: "284", color: "text-secondary" },
            ].map((s, i) => (
              <div key={i} className="flex justify-between items-center py-1.5 border-b border-border/40 last:border-0">
                <span className="text-xs text-muted-foreground">{s.label}</span>
                <span className={`text-sm font-bold ${s.color}`}>{s.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
