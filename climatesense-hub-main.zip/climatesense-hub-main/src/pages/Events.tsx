import { useState } from "react";
import { motion } from "framer-motion";
import { Calendar, MapPin, Users, Clock, Plus, Filter, Search, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import DashboardLayout from "@/components/DashboardLayout";

const categories = ["All", "Plantation", "Cleanup", "Workshop", "Awareness", "Campaign"];

const events = [
  {
    id: 1,
    title: "City Tree Plantation Drive",
    category: "Plantation",
    date: "March 22, 2025",
    time: "8:00 AM – 12:00 PM",
    location: "Central Park, New York",
    organizer: "GreenNYC Initiative",
    volunteers: 45,
    maxVolunteers: 100,
    desc: "Join us to plant 500+ native trees in Central Park. Equipment and refreshments provided. Help us restore the urban canopy and fight climate change one tree at a time.",
    icon: "🌳",
    color: "border-l-primary",
    registered: false,
  },
  {
    id: 2,
    title: "Marina Beach Cleanup Campaign",
    category: "Cleanup",
    date: "March 28, 2025",
    time: "7:00 AM – 11:00 AM",
    location: "Marina Beach, Los Angeles",
    organizer: "Ocean Warriors LA",
    volunteers: 78,
    maxVolunteers: 150,
    desc: "Help remove plastic and debris from one of LA's most popular beaches. We'll collect waste and analyze the types of pollution for our research database.",
    icon: "🏖️",
    color: "border-l-secondary",
    registered: true,
  },
  {
    id: 3,
    title: "Renewable Energy Workshop",
    category: "Workshop",
    date: "April 5, 2025",
    time: "10:00 AM – 4:00 PM",
    location: "Tech Hub, Austin, TX",
    organizer: "CleanTech Austin",
    volunteers: 32,
    maxVolunteers: 60,
    desc: "A hands-on workshop exploring solar panel installation, energy storage, and how to transition your home to renewable energy. Includes Q&A with certified engineers.",
    icon: "⚡",
    color: "border-l-warning",
    registered: false,
  },
  {
    id: 4,
    title: "Zero Waste Community Day",
    category: "Awareness",
    date: "April 12, 2025",
    time: "9:00 AM – 5:00 PM",
    location: "Millennium Park, Chicago",
    organizer: "Chicago Sustainability Network",
    volunteers: 91,
    maxVolunteers: 200,
    desc: "A full-day event with educational booths, composting demos, upcycling crafts, and speakers on zero-waste living. Family friendly and open to all!",
    icon: "♻️",
    color: "border-l-primary",
    registered: false,
  },
  {
    id: 5,
    title: "Urban Cycling & Climate Ride",
    category: "Campaign",
    date: "April 20, 2025",
    time: "7:30 AM – 11:00 AM",
    location: "Golden Gate Park, San Francisco",
    organizer: "SF Green Mobility",
    volunteers: 156,
    maxVolunteers: 300,
    desc: "Join hundreds of cyclists for a 15km ride through the city to promote sustainable transportation. The ride ends with a sustainability fair in the park.",
    icon: "🚴",
    color: "border-l-secondary",
    registered: false,
  },
  {
    id: 6,
    title: "Mangrove Restoration Project",
    category: "Plantation",
    date: "April 27, 2025",
    time: "8:00 AM – 2:00 PM",
    location: "Tampa Bay, Florida",
    organizer: "CoastCare Florida",
    volunteers: 28,
    maxVolunteers: 80,
    desc: "Plant mangrove saplings along the Tampa Bay coastline to restore natural storm barriers, improve water quality, and support marine biodiversity.",
    icon: "🌿",
    color: "border-l-primary",
    registered: false,
  },
];

export default function Events() {
  const [activeCategory, setActiveCategory] = useState("All");
  const [search, setSearch] = useState("");
  const [registeredEvents, setRegisteredEvents] = useState<number[]>([2]);
  const [showCreate, setShowCreate] = useState(false);

  const filtered = events.filter((e) => {
    const matchCat = activeCategory === "All" || e.category === activeCategory;
    const matchSearch = e.title.toLowerCase().includes(search.toLowerCase()) || e.location.toLowerCase().includes(search.toLowerCase());
    return matchCat && matchSearch;
  });

  const toggle = (id: number) => {
    setRegisteredEvents((prev) => prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]);
  };

  return (
    <DashboardLayout title="Climate Action Events" subtitle="Discover and join local climate events near you">
      {/* Actions bar */}
      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search events by title or location..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9 bg-card border-border/60 focus-visible:ring-primary"
          />
        </div>
        <Button
          onClick={() => setShowCreate(true)}
          className="bg-primary text-primary-foreground hover:bg-primary/90 shadow-glow-primary flex-shrink-0"
        >
          <Plus className="w-4 h-4 mr-2" /> Organize Event
        </Button>
      </div>

      {/* Category filters */}
      <div className="flex gap-2 flex-wrap mb-6">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setActiveCategory(cat)}
            className={`px-3 py-1.5 rounded-full text-xs font-semibold transition-all ${
              activeCategory === cat
                ? "bg-primary text-primary-foreground shadow-sm"
                : "bg-muted text-muted-foreground hover:bg-muted/80"
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Events grid */}
      <div className="grid md:grid-cols-2 gap-5">
        {filtered.map((event, i) => {
          const isRegistered = registeredEvents.includes(event.id);
          const pct = Math.round((event.volunteers / event.maxVolunteers) * 100);
          return (
            <motion.div
              key={event.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.07, duration: 0.4 }}
              className={`glass-card rounded-xl p-5 border-l-4 ${event.color} hover:shadow-elevated transition-all duration-300`}
            >
              <div className="flex items-start justify-between gap-3 mb-3">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">{event.icon}</span>
                  <div>
                    <span className="text-xs bg-muted text-muted-foreground px-2 py-0.5 rounded-full font-medium">{event.category}</span>
                    <h3 className="font-display font-bold text-foreground mt-1">{event.title}</h3>
                  </div>
                </div>
                {isRegistered && (
                  <span className="flex-shrink-0 flex items-center gap-1 text-xs text-primary font-semibold bg-primary/10 px-2 py-1 rounded-full">
                    <Check className="w-3 h-3" /> Registered
                  </span>
                )}
              </div>

              <p className="text-sm text-muted-foreground mb-4 leading-relaxed">{event.desc}</p>

              <div className="grid grid-cols-2 gap-2 mb-4 text-xs text-muted-foreground">
                <div className="flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-primary" />
                  {event.date}
                </div>
                <div className="flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-primary" />
                  {event.time}
                </div>
                <div className="flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-secondary" />
                  {event.location}
                </div>
                <div className="flex items-center gap-1.5">
                  <Users className="w-3.5 h-3.5 text-secondary" />
                  {event.volunteers}/{event.maxVolunteers} volunteers
                </div>
              </div>

              {/* Progress */}
              <div className="mb-4">
                <div className="flex justify-between text-xs text-muted-foreground mb-1">
                  <span>Volunteer spots filled</span>
                  <span className="font-semibold text-foreground">{pct}%</span>
                </div>
                <div className="h-1.5 rounded-full bg-muted overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${pct}%` }}
                    transition={{ duration: 1, delay: i * 0.1 }}
                    className="h-full rounded-full bg-primary"
                  />
                </div>
              </div>

              <div className="flex items-center justify-between">
                <p className="text-xs text-muted-foreground">by <span className="font-medium text-foreground">{event.organizer}</span></p>
                <Button
                  size="sm"
                  onClick={() => toggle(event.id)}
                  className={isRegistered
                    ? "bg-primary/10 text-primary hover:bg-primary/20 border border-primary/20"
                    : "bg-primary text-primary-foreground hover:bg-primary/90"
                  }
                >
                  {isRegistered ? "✓ Registered" : "Register Now"}
                </Button>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Create event modal (simplified) */}
      {showCreate && (
        <div className="fixed inset-0 bg-foreground/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-card rounded-2xl p-6 w-full max-w-lg shadow-elevated border border-border"
          >
            <h3 className="font-display text-xl font-bold text-foreground mb-4">Organize a Climate Event</h3>
            <div className="space-y-3">
              {["Event Title", "Description", "Location", "Date & Time", "Volunteers Needed"].map((field) => (
                <div key={field}>
                  <label className="text-xs font-semibold text-muted-foreground mb-1 block">{field}</label>
                  <Input placeholder={`Enter ${field.toLowerCase()}...`} className="bg-background border-border/60 focus-visible:ring-primary" />
                </div>
              ))}
            </div>
            <div className="flex gap-3 mt-5">
              <Button variant="outline" onClick={() => setShowCreate(false)} className="flex-1 border-border text-muted-foreground">Cancel</Button>
              <Button onClick={() => setShowCreate(false)} className="flex-1 bg-primary text-primary-foreground hover:bg-primary/90">Create Event</Button>
            </div>
          </motion.div>
        </div>
      )}
    </DashboardLayout>
  );
}
