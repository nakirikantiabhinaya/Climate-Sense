import { useState } from "react";
import { motion } from "framer-motion";
import { Users, Clock, Calendar, Star, Plus, MapPin, Check, Leaf } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import DashboardLayout from "@/components/DashboardLayout";

const skillOptions = ["Tree Planting", "Waste Management", "Education", "Photography", "Social Media", "Event Coordination", "Research", "Transportation", "Cooking", "Medical Aid"];

const opportunities = [
  {
    title: "Weekend Tree Planter",
    org: "GreenCity Initiative",
    location: "Central Park, NY",
    date: "Every Saturday",
    hours: 4,
    skills: ["Tree Planting"],
    desc: "Help plant and maintain native trees in urban green spaces. No experience needed — training provided!",
    icon: "🌳",
    urgency: "High Need",
  },
  {
    title: "Climate Education Facilitator",
    org: "EcoLearn Foundation",
    location: "Schools across NYC",
    date: "Weekdays",
    hours: 3,
    skills: ["Education", "Research"],
    desc: "Deliver climate education workshops to school children aged 8–14. Teaching experience preferred.",
    icon: "📚",
    urgency: "Seeking",
  },
  {
    title: "Beach Cleanup Crew",
    org: "Ocean Warriors",
    location: "Rockaway Beach, NY",
    date: "Bi-monthly",
    hours: 3,
    skills: ["Waste Management"],
    desc: "Join regular beach cleanup drives. Collect and categorize marine debris for our research database.",
    icon: "🌊",
    urgency: "High Need",
  },
  {
    title: "Community Garden Volunteer",
    org: "Brooklyn Urban Farms",
    location: "Brooklyn, NY",
    date: "Flexible",
    hours: 2,
    skills: ["Tree Planting", "Research"],
    desc: "Help maintain community vegetable gardens and teach sustainable growing techniques to residents.",
    icon: "🥬",
    urgency: "Seeking",
  },
];

const myStats = [
  { label: "Total Hours", value: "43", icon: Clock, color: "text-primary" },
  { label: "Events Joined", value: "16", icon: Calendar, color: "text-secondary" },
  { label: "Impact Score", value: "3,890", icon: Star, color: "text-primary" },
  { label: "Trees Planted", value: "198", icon: Leaf, color: "text-primary" },
];

export default function Volunteer() {
  const [selectedSkills, setSelectedSkills] = useState<string[]>(["Tree Planting", "Education"]);
  const [appliedOpps, setAppliedOpps] = useState<number[]>([]);

  const toggleSkill = (skill: string) =>
    setSelectedSkills((prev) => prev.includes(skill) ? prev.filter((s) => s !== skill) : [...prev, skill]);

  return (
    <DashboardLayout title="Volunteer Network" subtitle="Join climate action opportunities and track your environmental contributions">
      <div className="grid lg:grid-cols-3 gap-5">
        {/* Profile sidebar */}
        <div className="space-y-5">
          {/* Volunteer profile card */}
          <div className="glass-card p-5 rounded-xl">
            <div className="flex items-center gap-4 mb-5">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-primary/30 to-secondary/30 border-2 border-primary/30 flex items-center justify-center font-bold text-foreground text-lg">
                AJ
              </div>
              <div>
                <p className="font-display font-bold text-foreground">Alex Johnson</p>
                <p className="text-xs text-muted-foreground">Climate Warrior · New York</p>
                <span className="inline-block mt-1 text-xs bg-primary/10 text-primary px-2 py-0.5 rounded-full font-semibold">Rank #4 Global</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              {myStats.map((stat, i) => (
                <div key={i} className="bg-muted/50 rounded-xl p-3 text-center">
                  <stat.icon className={`w-4 h-4 ${stat.color} mx-auto mb-1`} />
                  <p className={`font-display font-extrabold text-lg ${stat.color}`}>{stat.value}</p>
                  <p className="text-[10px] text-muted-foreground">{stat.label}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Skills & interests */}
          <div className="glass-card p-5 rounded-xl">
            <h4 className="font-display font-bold text-foreground mb-3">My Skills & Interests</h4>
            <div className="flex flex-wrap gap-2">
              {skillOptions.map((skill) => (
                <button
                  key={skill}
                  onClick={() => toggleSkill(skill)}
                  className={`px-2.5 py-1 rounded-full text-xs font-medium transition-all ${
                    selectedSkills.includes(skill)
                      ? "bg-primary text-primary-foreground"
                      : "bg-muted text-muted-foreground hover:bg-muted/80"
                  }`}
                >
                  {skill}
                </button>
              ))}
            </div>
            <Button size="sm" className="mt-4 w-full bg-primary/10 text-primary hover:bg-primary/20 border border-primary/20">
              Update Profile
            </Button>
          </div>

          {/* Availability */}
          <div className="glass-card p-5 rounded-xl">
            <h4 className="font-display font-bold text-foreground mb-3">Availability</h4>
            <div className="space-y-2">
              {["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map((day, i) => (
                <div key={day} className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">{day}</span>
                  <div className="flex gap-1">
                    {["Morning", "Afternoon", "Evening"].map((time) => (
                      <button
                        key={time}
                        className={`w-6 h-6 rounded text-xs font-bold transition-all ${
                          (i < 5 && time !== "Morning") || (i >= 5)
                            ? "bg-primary/20 text-primary"
                            : "bg-muted text-muted-foreground"
                        }`}
                        title={time}
                      >
                        {time[0]}
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Opportunities */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-display font-bold text-foreground">Volunteer Opportunities Near You</h3>
            <span className="text-xs text-muted-foreground">{opportunities.length} available</span>
          </div>

          {opportunities.map((opp, i) => {
            const applied = appliedOpps.includes(i);
            return (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1, duration: 0.4 }}
                className="glass-card p-5 rounded-xl hover:shadow-elevated transition-all duration-300"
              >
                <div className="flex items-start gap-4">
                  <span className="text-2xl flex-shrink-0">{opp.icon}</span>
                  <div className="flex-1">
                    <div className="flex items-start justify-between gap-3 mb-2">
                      <div>
                        <div className="flex items-center gap-2 mb-0.5">
                          <h3 className="font-display font-bold text-foreground">{opp.title}</h3>
                          <span className={`text-xs px-2 py-0.5 rounded-full font-semibold ${opp.urgency === "High Need" ? "bg-destructive/10 text-destructive" : "bg-secondary/10 text-secondary"}`}>
                            {opp.urgency}
                          </span>
                        </div>
                        <p className="text-xs text-muted-foreground font-medium">{opp.org}</p>
                      </div>
                      <Button
                        size="sm"
                        onClick={() => setAppliedOpps((p) => p.includes(i) ? p.filter((x) => x !== i) : [...p, i])}
                        className={applied
                          ? "flex-shrink-0 bg-primary/10 text-primary hover:bg-primary/20 border border-primary/20"
                          : "flex-shrink-0 bg-primary text-primary-foreground hover:bg-primary/90"
                        }
                      >
                        {applied ? <><Check className="w-3.5 h-3.5 mr-1.5" />Applied</> : <><Plus className="w-3.5 h-3.5 mr-1.5" />Apply</>}
                      </Button>
                    </div>

                    <p className="text-sm text-muted-foreground mb-3 leading-relaxed">{opp.desc}</p>

                    <div className="flex flex-wrap gap-3 text-xs text-muted-foreground">
                      <div className="flex items-center gap-1.5">
                        <MapPin className="w-3.5 h-3.5 text-primary" />
                        {opp.location}
                      </div>
                      <div className="flex items-center gap-1.5">
                        <Calendar className="w-3.5 h-3.5 text-secondary" />
                        {opp.date}
                      </div>
                      <div className="flex items-center gap-1.5">
                        <Clock className="w-3.5 h-3.5 text-primary" />
                        {opp.hours}h/session
                      </div>
                    </div>

                    <div className="flex gap-2 flex-wrap mt-3">
                      {opp.skills.map((skill, j) => (
                        <span key={j} className="text-xs bg-primary/10 text-primary px-2 py-0.5 rounded-full font-medium">{skill}</span>
                      ))}
                    </div>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </DashboardLayout>
  );
}
