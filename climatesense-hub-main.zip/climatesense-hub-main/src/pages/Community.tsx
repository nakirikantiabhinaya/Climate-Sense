import { motion } from "framer-motion";
import {
  Globe, Users, TreePine, Droplets, TrendingDown, Map, BarChart3, Zap, Award
} from "lucide-react";
import {
  AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, LineChart, Line
} from "recharts";
import DashboardLayout from "@/components/DashboardLayout";

const globalStats = [
  { label: "Total Volunteers", value: "12,847", icon: Users, color: "text-secondary", bg: "bg-secondary/10", trend: "+843 this month" },
  { label: "CO₂ Reduced", value: "24,812 t", icon: TrendingDown, color: "text-primary", bg: "bg-primary/10", trend: "+1,240t this month" },
  { label: "Trees Planted", value: "89,420", icon: TreePine, color: "text-primary", bg: "bg-primary/10", trend: "+6,200 this month" },
  { label: "Waste Collected", value: "342 t", icon: Droplets, color: "text-secondary", bg: "bg-secondary/10", trend: "+18t this month" },
  { label: "Events Organized", value: "1,284", icon: Globe, color: "text-primary", bg: "bg-primary/10", trend: "+94 this month" },
  { label: "Cities Reached", value: "248", icon: Map, color: "text-secondary", bg: "bg-secondary/10", trend: "+12 this month" },
];

const monthlyImpact = [
  { month: "Sep", volunteers: 8200, trees: 54000, co2: 16200 },
  { month: "Oct", volunteers: 9100, trees: 61000, co2: 18100 },
  { month: "Nov", volunteers: 9800, trees: 67000, co2: 19400 },
  { month: "Dec", volunteers: 10200, trees: 72000, co2: 21000 },
  { month: "Jan", volunteers: 11100, trees: 78000, co2: 22300 },
  { month: "Feb", volunteers: 11900, trees: 83000, co2: 23600 },
  { month: "Mar", volunteers: 12847, trees: 89420, co2: 24812 },
];

const topCities = [
  { city: "Singapore", volunteers: 1840, trees: 12400 },
  { city: "San Francisco", volunteers: 1620, trees: 10800 },
  { city: "Berlin", volunteers: 1380, trees: 9200 },
  { city: "Mumbai", volunteers: 1290, trees: 8600 },
  { city: "New York", volunteers: 1180, trees: 7900 },
  { city: "Tokyo", volunteers: 1040, trees: 6900 },
];

const recentActivity = [
  { action: "🌳 Tree plantation drive completed", location: "Central Park, NY", time: "2h ago", impact: "+312 trees" },
  { action: "🏖️ Beach cleanup successful", location: "Marina Beach, CA", time: "5h ago", impact: "+2.4t waste removed" },
  { action: "⚡ Energy workshop held", location: "Austin, TX", time: "1d ago", impact: "+45 participants" },
  { action: "🚴 Climate cycling event", location: "Golden Gate, SF", time: "2d ago", impact: "+156 cyclists" },
  { action: "🌿 Mangrove restoration", location: "Tampa Bay, FL", time: "3d ago", impact: "+80 saplings" },
  { action: "♻️ Zero Waste Community Day", location: "Chicago, IL", time: "4d ago", impact: "+200 attendees" },
];

export default function Community() {
  return (
    <DashboardLayout title="Community Impact" subtitle="Global climate action impact across all ClimateSense communities">
      {/* Global stats grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-6">
        {globalStats.map((stat, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.07, duration: 0.4 }}
            className="glass-card p-4 rounded-xl"
          >
            <div className={`w-9 h-9 rounded-xl ${stat.bg} flex items-center justify-center mb-3`}>
              <stat.icon className={`w-4.5 h-4.5 ${stat.color}`} />
            </div>
            <p className={`font-display text-xl font-extrabold ${stat.color} leading-tight`}>{stat.value}</p>
            <p className="text-xs text-muted-foreground mt-0.5">{stat.label}</p>
            <p className="text-[10px] text-primary mt-1 font-medium">{stat.trend}</p>
          </motion.div>
        ))}
      </div>

      {/* Charts row */}
      <div className="grid lg:grid-cols-2 gap-5 mb-5">
        {/* Volunteer growth */}
        <div className="glass-card p-5 rounded-xl">
          <div className="mb-4">
            <h3 className="font-display font-bold text-foreground">Volunteer Growth</h3>
            <p className="text-xs text-muted-foreground">Community members joining monthly</p>
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <AreaChart data={monthlyImpact}>
              <defs>
                <linearGradient id="volGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(199 89% 40%)" stopOpacity={0.25} />
                  <stop offset="95%" stopColor="hsl(199 89% 40%)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(214 32% 91%)" />
              <XAxis dataKey="month" tick={{ fontSize: 11 }} tickLine={false} axisLine={false} />
              <YAxis tick={{ fontSize: 11 }} tickLine={false} axisLine={false} />
              <Tooltip contentStyle={{ borderRadius: 8, fontSize: 12 }} />
              <Area type="monotone" dataKey="volunteers" stroke="hsl(199 89% 40%)" strokeWidth={2.5} fill="url(#volGrad)" name="Volunteers" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Trees planted trend */}
        <div className="glass-card p-5 rounded-xl">
          <div className="mb-4">
            <h3 className="font-display font-bold text-foreground">CO₂ Reduction Progress</h3>
            <p className="text-xs text-muted-foreground">Cumulative tonnes reduced monthly</p>
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={monthlyImpact}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(214 32% 91%)" />
              <XAxis dataKey="month" tick={{ fontSize: 11 }} tickLine={false} axisLine={false} />
              <YAxis tick={{ fontSize: 11 }} tickLine={false} axisLine={false} />
              <Tooltip contentStyle={{ borderRadius: 8, fontSize: 12 }} />
              <Line type="monotone" dataKey="co2" stroke="hsl(160 84% 39%)" strokeWidth={2.5} dot={{ r: 4, fill: "hsl(160 84% 39%)" }} name="CO₂ Reduced (t)" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Bottom row */}
      <div className="grid lg:grid-cols-3 gap-5">
        {/* Top cities */}
        <div className="glass-card p-5 rounded-xl">
          <div className="flex items-center gap-2 mb-4">
            <Map className="w-4.5 h-4.5 text-secondary" />
            <h3 className="font-display font-bold text-foreground">Top Cities</h3>
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={topCities} layout="vertical" barSize={10}>
              <XAxis type="number" tick={{ fontSize: 10 }} tickLine={false} axisLine={false} />
              <YAxis dataKey="city" type="category" tick={{ fontSize: 11 }} tickLine={false} axisLine={false} width={75} />
              <Tooltip contentStyle={{ borderRadius: 8, fontSize: 12 }} />
              <Bar dataKey="volunteers" fill="hsl(199 89% 40%)" radius={[0, 4, 4, 0]} name="Volunteers" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Recent activity feed */}
        <div className="glass-card p-5 rounded-xl lg:col-span-2">
          <div className="flex items-center gap-2 mb-4">
            <Zap className="w-4.5 h-4.5 text-primary" />
            <h3 className="font-display font-bold text-foreground">Recent Community Activity</h3>
          </div>
          <div className="space-y-3">
            {recentActivity.map((item, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: 10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.08, duration: 0.3 }}
                className="flex items-center justify-between p-3 rounded-lg bg-muted/40 hover:bg-muted/60 transition-colors"
              >
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground truncate">{item.action}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">{item.location} · {item.time}</p>
                </div>
                <span className="flex-shrink-0 text-xs font-bold text-primary bg-primary/10 px-2 py-1 rounded-full ml-3">
                  {item.impact}
                </span>
              </motion.div>
            ))}
          </div>
        </div>
      </div>

      {/* SDG banner */}
      <div className="mt-5 glass-card p-5 rounded-xl border border-primary/20 bg-gradient-to-r from-primary/5 to-secondary/5">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center flex-shrink-0">
            <Globe className="w-7 h-7 text-primary" />
          </div>
          <div className="flex-1">
            <h4 className="font-display font-bold text-foreground">Supporting UN Sustainable Development Goal 13</h4>
            <p className="text-sm text-muted-foreground mt-0.5">ClimateSense AI is committed to climate action through community engagement, education, and real-world impact tracking.</p>
          </div>
          <div className="hidden md:flex gap-4 text-center flex-shrink-0">
            {[
              { value: "248", label: "Cities" },
              { value: "12.8K", label: "Volunteers" },
              { value: "89K", label: "Trees" },
            ].map((m, i) => (
              <div key={i}>
                <p className="font-display font-extrabold text-primary text-xl">{m.value}</p>
                <p className="text-xs text-muted-foreground">{m.label}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
