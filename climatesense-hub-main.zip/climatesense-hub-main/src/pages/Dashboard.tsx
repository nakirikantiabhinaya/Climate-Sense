import { motion } from "framer-motion";
import {
  AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend
} from "recharts";
import {
  TrendingDown, Leaf, Award, Users, Calendar, Zap,
  ArrowUp, ArrowDown, Target, Clock, Globe
} from "lucide-react";
import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

const emissionsTrend = [
  { month: "Aug", emissions: 4.8 },
  { month: "Sep", emissions: 4.2 },
  { month: "Oct", emissions: 3.9 },
  { month: "Nov", emissions: 4.1 },
  { month: "Dec", emissions: 3.6 },
  { month: "Jan", emissions: 3.2 },
  { month: "Feb", emissions: 2.9 },
  { month: "Mar", emissions: 2.7 },
];

const emissionsByCategory = [
  { name: "Transport", value: 38, color: "#0284C7" },
  { name: "Energy", value: 28, color: "#10B981" },
  { name: "Food", value: 22, color: "#F59E0B" },
  { name: "Lifestyle", value: 12, color: "#EF4444" },
];

const monthlyActivity = [
  { month: "Oct", hours: 4, events: 1 },
  { month: "Nov", hours: 6, events: 2 },
  { month: "Dec", hours: 3, events: 1 },
  { month: "Jan", hours: 8, events: 3 },
  { month: "Feb", hours: 10, events: 4 },
  { month: "Mar", hours: 12, events: 5 },
];

const stats = [
  { label: "Carbon Score", value: "2.7", unit: "t CO₂/mo", icon: TrendingDown, change: -18, color: "text-primary", bg: "bg-primary/10" },
  { label: "Sustainability Score", value: "87", unit: "/ 100", icon: Leaf, change: +5, color: "text-primary", bg: "bg-primary/10" },
  { label: "Volunteer Hours", value: "43", unit: "hrs", icon: Clock, change: +12, color: "text-secondary", bg: "bg-secondary/10" },
  { label: "Events Attended", value: "16", unit: "events", icon: Calendar, change: +3, color: "text-secondary", bg: "bg-secondary/10" },
];

const badges = [
  { name: "Eco Beginner", earned: true, icon: "🌱", desc: "First carbon calculation" },
  { name: "Climate Warrior", earned: true, icon: "⚡", desc: "10+ events attended" },
  { name: "Sustainability Champ", earned: true, icon: "🏆", desc: "Score above 80" },
  { name: "Green Leader", earned: false, icon: "👑", desc: "100+ volunteer hours" },
  { name: "CO₂ Reducer", earned: true, icon: "🌍", desc: "20% reduction achieved" },
  { name: "Community Hero", earned: false, icon: "🤝", desc: "Organized 5 events" },
];

const alerts = [
  { type: "high", title: "Heat Index Warning", desc: "Feels like 42°C today. Avoid outdoor activity.", time: "2h ago" },
  { type: "medium", title: "Air Quality Moderate", desc: "AQI: 78. Sensitive groups should limit exposure.", time: "5h ago" },
  { type: "low", title: "UV Index High", desc: "UV Index: 8. Wear sunscreen if going outdoors.", time: "8h ago" },
];

export default function Dashboard() {
  const fadeUp = {
    hidden: { opacity: 0, y: 20 },
    visible: (i: number) => ({ opacity: 1, y: 0, transition: { delay: i * 0.08, duration: 0.5 } }),
  };

  return (
    <DashboardLayout title="My Dashboard" subtitle="Your personal climate intelligence hub">
      {/* Greeting */}
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h2 className="font-display text-2xl font-bold text-foreground">
            Welcome back, Alex 👋
          </h2>
          <p className="text-sm text-muted-foreground mt-1">
            You've reduced your carbon footprint by <span className="text-primary font-semibold">18%</span> this month. Keep going!
          </p>
        </div>
        <Button asChild size="sm" className="bg-primary text-primary-foreground hover:bg-primary/90 shadow-sm">
          <Link to="/calculator">
            <Zap className="w-4 h-4 mr-2" /> Quick Calculate
          </Link>
        </Button>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {stats.map((stat, i) => (
          <motion.div
            key={i}
            custom={i}
            initial="hidden"
            animate="visible"
            variants={fadeUp}
            className="stat-card"
          >
            <div className="flex items-center justify-between">
              <div className={`w-9 h-9 rounded-xl ${stat.bg} flex items-center justify-center`}>
                <stat.icon className={`w-4.5 h-4.5 ${stat.color}`} />
              </div>
              <span className={`text-xs font-semibold flex items-center gap-0.5 ${stat.change >= 0 ? "text-primary" : "text-destructive"}`}>
                {stat.change >= 0 ? <ArrowUp className="w-3 h-3" /> : <ArrowDown className="w-3 h-3" />}
                {Math.abs(stat.change)}%
              </span>
            </div>
            <div className="mt-3">
              <p className={`font-display text-3xl font-extrabold ${stat.color}`}>
                {stat.value}
                <span className="text-base font-medium text-muted-foreground ml-1">{stat.unit}</span>
              </p>
              <p className="text-xs text-muted-foreground mt-0.5">{stat.label}</p>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Charts row */}
      <div className="grid lg:grid-cols-3 gap-5 mb-5">
        {/* Emissions trend */}
        <div className="glass-card p-5 lg:col-span-2 rounded-xl">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-display font-bold text-foreground">Emissions Trend</h3>
              <p className="text-xs text-muted-foreground">Monthly CO₂ (tonnes) — last 8 months</p>
            </div>
            <span className="text-xs bg-primary/10 text-primary px-2 py-1 rounded-full font-semibold">↓ 43% since Aug</span>
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <AreaChart data={emissionsTrend}>
              <defs>
                <linearGradient id="emGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(160 84% 39%)" stopOpacity={0.25} />
                  <stop offset="95%" stopColor="hsl(160 84% 39%)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(214 32% 91%)" />
              <XAxis dataKey="month" tick={{ fontSize: 11 }} tickLine={false} axisLine={false} />
              <YAxis tick={{ fontSize: 11 }} tickLine={false} axisLine={false} />
              <Tooltip
                contentStyle={{ background: "hsl(0 0% 100%)", border: "1px solid hsl(214 32% 91%)", borderRadius: 8, fontSize: 12 }}
              />
              <Area
                type="monotone"
                dataKey="emissions"
                stroke="hsl(160 84% 39%)"
                strokeWidth={2.5}
                fill="url(#emGrad)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Pie chart */}
        <div className="glass-card p-5 rounded-xl">
          <div className="mb-4">
            <h3 className="font-display font-bold text-foreground">Emissions Breakdown</h3>
            <p className="text-xs text-muted-foreground">By category</p>
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie
                data={emissionsByCategory}
                cx="50%"
                cy="50%"
                innerRadius={55}
                outerRadius={80}
                paddingAngle={3}
                dataKey="value"
              >
                {emissionsByCategory.map((entry, index) => (
                  <Cell key={index} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip formatter={(val) => [`${val}%`, ""]} contentStyle={{ borderRadius: 8, fontSize: 12 }} />
            </PieChart>
          </ResponsiveContainer>
          <div className="space-y-1.5 mt-1">
            {emissionsByCategory.map((cat, i) => (
              <div key={i} className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full" style={{ background: cat.color }} />
                  <span className="text-muted-foreground">{cat.name}</span>
                </div>
                <span className="font-semibold text-foreground">{cat.value}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Bottom row */}
      <div className="grid lg:grid-cols-3 gap-5">
        {/* Activity chart */}
        <div className="glass-card p-5 lg:col-span-2 rounded-xl">
          <div className="mb-4">
            <h3 className="font-display font-bold text-foreground">Volunteer Activity</h3>
            <p className="text-xs text-muted-foreground">Hours &amp; events per month</p>
          </div>
          <ResponsiveContainer width="100%" height={160}>
            <BarChart data={monthlyActivity} barSize={16}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(214 32% 91%)" />
              <XAxis dataKey="month" tick={{ fontSize: 11 }} tickLine={false} axisLine={false} />
              <YAxis tick={{ fontSize: 11 }} tickLine={false} axisLine={false} />
              <Tooltip contentStyle={{ borderRadius: 8, fontSize: 12 }} />
              <Bar dataKey="hours" fill="hsl(160 84% 39%)" radius={[4, 4, 0, 0]} name="Hours" />
              <Bar dataKey="events" fill="hsl(199 89% 40%)" radius={[4, 4, 0, 0]} name="Events" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Active Alerts panel */}
        <div className="glass-card p-5 rounded-xl">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-display font-bold text-foreground">Active Alerts</h3>
            <Link to="/alerts" className="text-xs text-primary hover:underline">View all</Link>
          </div>
          <div className="space-y-3">
            {alerts.map((alert, i) => (
              <div
                key={i}
                className={`p-3 rounded-lg border text-xs ${
                  alert.type === "high"
                    ? "bg-destructive/8 border-destructive/20"
                    : alert.type === "medium"
                    ? "border-warning/20"
                    : "bg-primary/5 border-primary/20"
                }`}
                style={alert.type === "medium" ? { background: "hsl(var(--warning) / 0.05)" } : {}}
              >
                <div className="flex items-center gap-1.5 mb-0.5">
                  {alert.type === "high" && <span className="inline-block w-1.5 h-1.5 rounded-full bg-destructive animate-ping" />}
                  {alert.type === "medium" && <span className="inline-block w-1.5 h-1.5 rounded-full" style={{ background: "hsl(var(--warning))" }} />}
                  {alert.type === "low" && <span className="inline-block w-1.5 h-1.5 rounded-full bg-primary" />}
                  <span className="font-semibold text-foreground">{alert.title}</span>
                </div>
                <p className="text-muted-foreground">{alert.desc}</p>
                <p className="text-muted-foreground/60 mt-1">{alert.time}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Badges */}
      <div className="glass-card p-5 rounded-xl mt-5">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="font-display font-bold text-foreground">Achievement Badges</h3>
            <p className="text-xs text-muted-foreground">4 of 6 earned</p>
          </div>
          <Link to="/leaderboard" className="text-xs text-primary hover:underline">View Leaderboard</Link>
        </div>
        <div className="grid grid-cols-3 sm:grid-cols-6 gap-3">
          {badges.map((badge, i) => (
            <div
              key={i}
              className={`flex flex-col items-center text-center p-3 rounded-xl border transition-all ${
                badge.earned
                  ? "bg-primary/5 border-primary/20 hover:shadow-sm"
                  : "opacity-40 bg-muted border-border"
              }`}
            >
              <span className="text-2xl mb-1">{badge.icon}</span>
              <p className="text-xs font-semibold text-foreground leading-tight">{badge.name}</p>
              <p className="text-[10px] text-muted-foreground mt-0.5 leading-tight">{badge.desc}</p>
              {badge.earned && <span className="mt-1.5 text-[9px] font-bold text-primary uppercase tracking-wide">Earned</span>}
            </div>
          ))}
        </div>
      </div>
    </DashboardLayout>
  );
}
