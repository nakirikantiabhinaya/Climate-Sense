import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Bot, Send, User, Leaf, Zap, Sparkles, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import DashboardLayout from "@/components/DashboardLayout";

interface Message {
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
}

const suggestions = [
  "How can I reduce my carbon footprint at home?",
  "What are the best eco-friendly habits to adopt?",
  "How can I save energy in my daily routine?",
  "What foods have the lowest carbon impact?",
  "How to reduce plastic waste effectively?",
  "What are the easiest switches to renewable energy?",
];

const mockResponses: Record<string, string> = {
  default: `Great question! Here are **actionable tips** to reduce your environmental impact:

## 🏠 At Home
- **Switch to LED bulbs** — saves up to 75% energy vs incandescent
- **Install a smart thermostat** — can reduce heating/cooling costs by 10–15%
- **Unplug devices** when not in use (vampire power accounts for 10% of electricity)
- **Insulate your home** properly to reduce energy loss

## 🚗 Transportation  
- **Walk or cycle** for trips under 3km — zero emissions!
- **Use public transport** for daily commute
- **Carpool** to reduce per-person emissions by 50%
- Consider an **electric vehicle** for your next car

## 🥗 Food Choices
- **Reduce meat** consumption (especially beef & lamb)
- **Buy local and seasonal** produce to cut transport emissions
- **Compost food waste** instead of landfilling

## 💚 Quick Wins
- Carry a reusable bag, bottle, and coffee cup
- Choose products with minimal packaging
- Support companies with sustainability commitments

Your daily choices make a **real difference**! Would you like to dive deeper into any of these areas? 🌱`,
};

const getResponse = (query: string): string => {
  const q = query.toLowerCase();
  if (q.includes("carbon") || q.includes("footprint")) {
    return `## Reducing Your Carbon Footprint

Your carbon footprint comes from **4 main areas**:

1. **Transportation (38%)** — Biggest impact. Switching to an EV or using public transit can cut this in half.

2. **Home Energy (28%)** — Switch to renewable energy sources. Solar panels typically pay off in 6–8 years.

3. **Food (22%)** — Going plant-based 3 days/week reduces food emissions by ~30%.

4. **Consumer goods (12%)** — Buy less, buy used, choose durable items.

**Your Next Steps:**
- Take our Carbon Calculator to get your exact baseline
- Set a 20% reduction goal for this month
- Track progress on your Dashboard

The global average is 4.8 tonnes/year. The Paris Agreement target is under 2 tonnes. What's your current score? 🌍`;
  }
  if (q.includes("energy") || q.includes("electricity")) {
    return `## Energy Saving Guide 💡

**Immediate actions (zero cost):**
- Turn off lights when leaving rooms
- Wash clothes in cold water (90% of energy goes to heating water)
- Set fridge to 3–4°C and freezer to -18°C
- Use power strips to eliminate standby power

**Medium investment:**
- LED lighting throughout your home (80% energy savings)
- Smart power strips and timers
- Programmable thermostat

**High impact investments:**
- Solar panels — typically 6–10 year payback
- Heat pump water heater — 3x more efficient than electric
- Home insulation upgrade

**Did you know?** A typical home wastes 15–30% of energy on heating/cooling due to poor insulation. Sealing drafts alone can save $200+/year!

Want me to calculate potential savings for your home? 🏠`;
  }
  if (q.includes("food") || q.includes("diet")) {
    return `## Sustainable Eating Guide 🥗

**Carbon impact by diet type (kg CO₂/day):**
- Vegan: 1.5 kg
- Vegetarian: 1.7 kg  
- Mixed: 2.2 kg
- Meat-heavy: 3.3 kg

**High-impact swaps:**
- Beef → Chicken (85% less carbon) or Lentils (96% less)
- Dairy milk → Oat milk (80% less carbon)
- Imported produce → Local seasonal vegetables

**Practical tips:**
1. Try "Meatless Mondays" — just 1 day/week saves ~53kg CO₂/year
2. Plan meals to reduce food waste (30% of food is thrown away!)
3. Grow herbs at home — fresh & zero-carbon
4. Choose whole foods over heavily processed items

**Zero-waste eating:**
- Compost scraps
- Buy in bulk to reduce packaging
- Use the whole vegetable (stems, leaves, seeds)

Small dietary changes have **huge cumulative impact**! 🌱`;
  }
  return mockResponses.default;
};

export default function Advisor() {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant",
      content: `Hello! I'm **ClimateSense AI**, your personal sustainability advisor. 🌿

I can help you with:
- 📊 Understanding your carbon footprint
- 🏠 Energy-saving strategies for home & office
- 🥗 Sustainable diet choices
- 🌍 Climate action tips and eco-friendly habits
- ♻️ Waste reduction strategies

What would you like to explore today?`,
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const send = async (text: string) => {
    if (!text.trim()) return;
    const userMsg: Message = { role: "user", content: text, timestamp: new Date() };
    setMessages((prev) => [...prev, userMsg]);
    setInput("");
    setLoading(true);
    await new Promise((r) => setTimeout(r, 1200));
    const reply = getResponse(text);
    setMessages((prev) => [...prev, { role: "assistant", content: reply, timestamp: new Date() }]);
    setLoading(false);
  };

  const formatContent = (content: string) => {
    return content
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      .replace(/## (.*?)(\n|$)/g, '<h3 class="font-display font-bold text-foreground text-base mt-3 mb-1">$1</h3>')
      .replace(/\n/g, '<br />')
      .replace(/- (.*?)(<br|$)/g, '<li class="ml-4 text-sm">• $1</li>');
  };

  return (
    <DashboardLayout title="AI Sustainability Advisor" subtitle="Get personalized eco-friendly guidance powered by AI">
      <div className="grid lg:grid-cols-4 gap-5 h-[calc(100vh-160px)]">
        {/* Chat panel */}
        <div className="lg:col-span-3 flex flex-col glass-card rounded-xl overflow-hidden">
          {/* Header */}
          <div className="px-5 py-4 border-b border-border/60 flex items-center justify-between bg-card/50">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-primary/10 flex items-center justify-center">
                <Bot className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="font-display font-bold text-sm text-foreground">ClimateSense AI</p>
                <div className="flex items-center gap-1.5">
                  <div className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
                  <p className="text-xs text-muted-foreground">Online · Sustainability Expert</p>
                </div>
              </div>
            </div>
            <Button variant="ghost" size="sm" onClick={() => setMessages([messages[0]])} className="text-muted-foreground hover:text-foreground">
              <RefreshCw className="w-3.5 h-3.5 mr-1" /> Clear
            </Button>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-5 space-y-4">
            <AnimatePresence>
              {messages.map((msg, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3 }}
                  className={`flex gap-3 ${msg.role === "user" ? "flex-row-reverse" : ""}`}
                >
                  <div className={`flex-shrink-0 w-8 h-8 rounded-xl flex items-center justify-center ${msg.role === "assistant" ? "bg-primary/10" : "bg-secondary/10"}`}>
                    {msg.role === "assistant" ? <Bot className="w-4 h-4 text-primary" /> : <User className="w-4 h-4 text-secondary" />}
                  </div>
                  <div
                    className={`max-w-[80%] px-4 py-3 rounded-2xl text-sm leading-relaxed ${
                      msg.role === "assistant"
                        ? "bg-card border border-border/60 text-foreground rounded-tl-sm"
                        : "bg-primary text-primary-foreground rounded-tr-sm"
                    }`}
                    dangerouslySetInnerHTML={{ __html: formatContent(msg.content) }}
                  />
                </motion.div>
              ))}
            </AnimatePresence>

            {loading && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex gap-3"
              >
                <div className="w-8 h-8 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <Bot className="w-4 h-4 text-primary" />
                </div>
                <div className="px-4 py-3 rounded-2xl bg-card border border-border/60 rounded-tl-sm">
                  <div className="flex gap-1 items-center h-5">
                    {[0, 1, 2].map((j) => (
                      <motion.div
                        key={j}
                        className="w-2 h-2 rounded-full bg-primary/40"
                        animate={{ scale: [1, 1.4, 1], opacity: [0.5, 1, 0.5] }}
                        transition={{ repeat: Infinity, duration: 1, delay: j * 0.2 }}
                      />
                    ))}
                  </div>
                </div>
              </motion.div>
            )}
            <div ref={endRef} />
          </div>

          {/* Input */}
          <div className="p-4 border-t border-border/60 bg-card/30">
            <div className="flex gap-3">
              <Textarea
                placeholder="Ask about sustainability, carbon reduction, eco-friendly tips..."
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(input); }}}
                rows={2}
                className="flex-1 resize-none text-sm bg-background border-border/60 focus-visible:ring-primary"
              />
              <Button
                onClick={() => send(input)}
                disabled={!input.trim() || loading}
                className="bg-primary text-primary-foreground hover:bg-primary/90 shadow-glow-primary self-end h-10"
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>

        {/* Suggestions sidebar */}
        <div className="space-y-4">
          <div className="glass-card p-4 rounded-xl">
            <div className="flex items-center gap-2 mb-3">
              <Sparkles className="w-4 h-4 text-primary" />
              <h4 className="font-display font-bold text-sm text-foreground">Quick Questions</h4>
            </div>
            <div className="space-y-2">
              {suggestions.map((s, i) => (
                <button
                  key={i}
                  onClick={() => send(s)}
                  className="w-full text-left text-xs text-muted-foreground hover:text-foreground p-2.5 rounded-lg bg-muted/50 hover:bg-muted transition-all leading-relaxed hover:border-primary/20 border border-transparent"
                >
                  {s}
                </button>
              ))}
            </div>
          </div>

          <div className="glass-card p-4 rounded-xl">
            <div className="flex items-center gap-2 mb-3">
              <Zap className="w-4 h-4 text-primary" />
              <h4 className="font-display font-bold text-sm text-foreground">AI Capabilities</h4>
            </div>
            <div className="space-y-2">
              {[
                "🌱 Carbon footprint advice",
                "⚡ Energy savings tips",
                "🥗 Sustainable diet guide",
                "♻️ Waste reduction",
                "🌍 Climate education",
                "📊 Eco habit tracking",
              ].map((cap, i) => (
                <p key={i} className="text-xs text-muted-foreground">{cap}</p>
              ))}
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
